# 🍵 Global Tea Cafe — Multi-Outlet Lucky Spin Wheel & Admin System

Global Tea Cafe ke 70 outlets ke liye complete, production-ready Lucky Spin Game aur Master Admin Panel.

---

## 🌟 Key Highlights & Features

1. **Dynamic Outlets Management ("➕ Add New Outlet")**:
   - Aap Admin Panel me jakar **"➕ Add New Outlet"** button se koi bhi store manually add kar sakte hain.
   - Har store ka **alag unique link**, **alag QR code standee**, **Edit & Delete** option, aur **isolated 100-spin quota engine** automatically ban jata hai.
   - Example: `http://localhost:8080/index.html?outlet=<store-id>` ya `http://192.168.1.75:8080/index.html?outlet=<store-id>`

2. **Customer Flow (Mobile-First)**:
   - Customer QR scan karega ya link kholega.
   - **Step 1:** Customer apna **Name** aur **10-Digit Mobile Number** enter karega.
   - Anti-Fraud Check: Ek customer ek din me ek hi baar spin kar sakta hai.
   - **Step 2:** Interactive Spin Wheel ghume ga (sound effects, haptic vibration aur ticking physics ke saath).
   - **Step 3:** Digital Winning Voucher display hoga jisme unique coupon code (`GTC-01-XXXXX`), WhatsApp Share button aur Copy button hoga.

3. **Isolated 100-Spin Quota Engine (Exact Probability Formula)**:
   - Har store ka cycle isolated (alag-alag) track hota hai.
   - **Har 100 spin me strictly:**
     - ☕ **7 baar Free Chai**
     - 🍔 **3 baar Free Burger**
     - 🍕 **3 baar Free Pizza**
     - 🏷️ **5 baar 15% OFF**
     - 🌟 **1 baar 25% OFF**
     - 🍀 **81 baar Better Luck Next Time**
   - Kisi bhi store me 100 spin hone par automatic naya cycle shuru ho jata hai aur quota reset ho jata hai.

4. **Programmed Terms & Conditions**:
   - ✅ **Min Order Value:** Offer **₹110 ke order ke upar** hi apply hoga.
   - ✅ **Mandatory Location:** Spin **billing counter ya dine-in table** par hi karna padega tabhi valid hoga.
   - ✅ **Next Visit Redemption:** Free Chai, Coffee, Burger aur Pizza **next visit** par redeem hoga.
   - ✅ **Validity:** Voucher 7 din ke liye valid hai.

5. **Master Admin Panel (`admin.html`)**:
   - **Live Activity Feed:** Jis store me jo customer data enter karega, turant admin panel me dikhega.
   - **Filter & Search:** Store-wise filter, prize-wise filter, search by phone number/coupon code.
   - **1-Click Excel / CSV Export:** Pure 70 stores ka customer data ek click me download karein.
   - **100-Spin Quota Monitor:** Dekhein kis store me kitne spin bache hain aur kitni chai/burger/pizza win ho chuki hai.
   - **Cashier Quick Redeem Terminal:** Counter par cashier coupon code ya phone no daal kar "Redeem Now" click karega (double redemption block hoti hai).

6. **Table Standee / QR Code Generator (`standee.html`)**:
   - Tables aur billing counter par lagane ke liye ready-to-print tent card / standee.
   - Global Tea Cafe brand logo, outlet ka naam, scannable QR code aur rules printed aate hain.
   - Simply browser me `Ctrl + P` dabayein aur A5 standee print karein!

---

## 🚀 How to Run (Kaise Start Karein)

### Step 1: Server Start Karein (1-Click)
Folder me `run_server.bat` file par **Double Click** karein.
Aapka native Windows server start ho jayega:
- Local Machine URL: `http://localhost:8080`
- Mobile URL (Same Wi-Fi): `http://192.168.1.75:8080`

*(Note: Isme koi alag Node.js ya Python install karne ki zaroorat nahi hai, ye Windows ke native engine par chalta hai).*

### Step 2: Open Admin Panel (Protected with ID & Password)
Browser me open karein:
👉 `http://localhost:8080/admin.html`

**Default Admin Credentials:**
- **Admin ID:** `admin`
- **Password:** `gtc@2026`

*(Aap login karne ke baad Settings tab me jakar apna ID aur Password kabhi bhi change kar sakte hain).*

### Step 3: Open Customer Spin Game
Customer ke liye open karein (Outlet 1 test karne ke liye):
👉 `http://localhost:8080/index.html?outlet=outlet_01`
(Kisi bhi outlet ka number change kar sakte hain, e.g. `outlet_02`, `outlet_70`).

### Step 4: Standee / QR Code Print Karein
Dining table aur billing counter standees print karne ke liye:
👉 `http://localhost:8080/standee.html?outlet=outlet_01`

---

## 📁 Project Structure

```text
new spin/
├── img/
│   └── Logo.webp           # Global Tea Cafe Official Logo
├── css/
│   ├── style.css           # Customer Mobile Game UI Styling
│   └── admin.css           # Admin Dashboard Styling
├── js/
│   ├── audio.js            # Web Audio Synthesizer (Realistic Ticks & Win Chimes)
│   ├── wheel.js            # Canvas Lucky Spin Wheel Engine
│   ├── game.js             # Customer Flow & Voucher Generation
│   ├── admin.js            # Admin Controller, Quota Monitor & Excel Export
│   └── data-store.js       # Unified Data & API Layer
├── data/
│   └── db.json             # Persistent Database (70 Outlets & Customer Records)
├── index.html              # Customer Spin Game Interface
├── admin.html              # Master Admin Portal & Cashier Desk
├── standee.html            # Printable Table Tent & QR Standee Generator
├── server.ps1              # High-Speed Native Windows REST API Server
├── run_server.bat          # 1-Click Server Launcher
└── README.md               # Complete Documentation & Usage Guide
```

---

## 🔒 Security & Anti-Fraud Rules
1. **Daily Limit Per Phone:** Ek phone number se ek outlet par din me 1 hi spin allowed hai. Repeat karne par unka active voucher hi display hota hai.
2. **Double-Redeem Protection:** Ek baar cashier ne voucher redeem kiya toh status timestamp ke saath save ho jata hai. Dobara redeem karne par error alert aata hai.
3. **Consolation Entry Guard:** "Better Luck Next Time" voucher redeem desk par redeem nahi kiya ja sakta.
