# Global Tea Cafe - Micro Web & REST API Server
# Native Windows PowerShell HTTPListener (Zero Dependencies)

$port = 8080
$dbPath = "$PSScriptRoot\data\db.json"
$lock = [System.Object]::new()

# MIME Types Dictionary
$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".webp" = "image/webp"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".svg"  = "image/svg+xml"
    ".ico"  = "image/x-icon"
    ".woff2"= "font/woff2"
    ".woff" = "font/woff"
    ".ttf"  = "font/ttf"
}

# Function to read database safely
function Get-Database {
    [System.Threading.Monitor]::Enter($lock)
    try {
        if (Test-Path $dbPath) {
            $raw = [System.IO.File]::ReadAllText($dbPath, [System.Text.Encoding]::UTF8)
            return ($raw | ConvertFrom-Json)
        }
        return $null
    }
    finally {
        [System.Threading.Monitor]::Exit($lock)
    }
}

# Function to write database safely
function Save-Database ($dbObj) {
    [System.Threading.Monitor]::Enter($lock)
    try {
        $json = $dbObj | ConvertTo-Json -Depth 10
        [System.IO.File]::WriteAllText($dbPath, $json, [System.Text.Encoding]::UTF8)
    }
    finally {
        [System.Threading.Monitor]::Exit($lock)
    }
}

# Helper to read request body without blocking on TCP Keep-Alive
function Read-RequestBody ($req) {
    if ($req.ContentLength64 -le 0) { return "" }
    $buffer = New-Object byte[] $req.ContentLength64
    $bytesRead = 0
    while ($bytesRead -lt $req.ContentLength64) {
        $read = $req.InputStream.Read($buffer, $bytesRead, ($req.ContentLength64 - $bytesRead))
        if ($read -le 0) { break }
        $bytesRead += $read
    }
    return [System.Text.Encoding]::UTF8.GetString($buffer, 0, $bytesRead)
}

# Helper to send JSON responses cleanly
function Send-JsonResponse ($res, $data, $statusCode = 200) {
    $res.StatusCode = $statusCode
    $res.ContentType = "application/json; charset=utf-8"
    if ($null -eq $data) {
        $json = "null"
    } elseif ($data -is [System.Collections.IEnumerable] -and -not ($data -is [string]) -and -not ($data -is [System.Collections.IDictionary])) {
        $arr = @($data)
        if ($arr.Count -eq 0) {
            $json = "[]"
        } elseif ($arr.Count -eq 1) {
            $itemJson = $arr[0] | ConvertTo-Json -Depth 10
            $json = "[$itemJson]"
        } else {
            $json = $arr | ConvertTo-Json -Depth 10
        }
    } else {
        $json = $data | ConvertTo-Json -Depth 10
        if ($null -eq $json -or $json -eq "") { $json = "{}" }
    }
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes, 0, $bytes.Length)
    $res.Close()
}

# Function to get Local IPv4
function Get-LocalIP {
    $ip = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { 
        $_.InterfaceAlias -notlike "*Loopback*" -and $_.IPAddress -notlike "169.254*" 
    } | Select-Object -First 1 -ExpandProperty IPAddress
    if (-not $ip) { $ip = "127.0.0.1" }
    return $ip
}

# Initialize and start listener
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Prefixes.Add("http://127.0.0.1:$port/")

try {
    $listener.Start()
}
catch {
    Write-Host "Failed to start listener on port $port : $_" -ForegroundColor Red
    exit 1
}

$localIP = Get-LocalIP
Write-Host "==========================================================" -ForegroundColor Green
Write-Host "  GLOBAL TEA CAFE - SPIN WHEEL & ADMIN SERVER STARTED     " -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Green
Write-Host "Local Machine URL:   http://localhost:$port" -ForegroundColor Cyan
Write-Host "Customer Mobile URL: http://${localIP}:$port" -ForegroundColor Cyan
Write-Host "Admin Panel:         http://localhost:${port}/admin.html" -ForegroundColor Yellow
Write-Host "Press Ctrl+C to stop the server." -ForegroundColor Gray
Write-Host "==========================================================" -ForegroundColor Green

# Prize Metadata & Quotas
$PRIZE_CONFIG = @{
    "chai"   = @{ key = "chai";   title = "Free Chai";   quota = 7;  type = "item";     color = "#0e4d36"; icon = "chai" }
    "burger" = @{ key = "burger"; title = "Free Burger"; quota = 3;  type = "item";     color = "#d97706"; icon = "burger" }
    "pizza"  = @{ key = "pizza";  title = "Free Pizza";  quota = 3;  type = "item";     color = "#dc2626"; icon = "pizza" }
    "off15"  = @{ key = "off15";  title = "15% OFF";     quota = 5;  type = "discount"; color = "#2563eb"; icon = "15off" }
    "off25"  = @{ key = "off25";  title = "25% OFF";     quota = 1;  type = "discount"; color = "#7c3aed"; icon = "25off" }
    "miss"   = @{ key = "miss";   title = "Better Luck Next Time"; quota = 81; type = "none"; color = "#64748b"; icon = "miss" }
}

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        # Add CORS Headers
        $response.AddHeader("Access-Control-Allow-Origin", "*")
        $response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE")
        $response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")

        if ($request.HttpMethod -eq "OPTIONS") {
            $response.StatusCode = 204
            $response.Close()
            continue
        }

        $rawUrl = $request.Url.AbsolutePath
        $httpMethod = $request.HttpMethod

        # REST API ROUTING
        if ($rawUrl.StartsWith("/api/")) {

            # --- API: Status ---
            if ($rawUrl -eq "/api/status" -and $httpMethod -eq "GET") {
                $db = Get-Database
                $outletsCount = if ($db.outlets) { $db.outlets.Count } else { 0 }
                $recordsCount = if ($db.records) { $db.records.Count } else { 0 }
                $resData = @{
                    status = "online"
                    serverTime = (Get-Date).ToString("o")
                    localIP = $localIP
                    port = $port
                    outletsCount = $outletsCount
                    recordsCount = $recordsCount
                }
                Send-JsonResponse $response $resData
                continue
            }

            # --- API: Admin Login ---
            if ($rawUrl -eq "/api/admin/login" -and $httpMethod -eq "POST") {
                $bodyStr = Read-RequestBody $request
                $body = $bodyStr | ConvertFrom-Json

                $user = ("" + $body.username).Trim()
                $pass = ("" + $body.password).Trim()

                $db = Get-Database
                $auth = $db.adminAuth
                $validUser = if ($auth -and $auth.username) { $auth.username } else { "admin" }
                $validPass = if ($auth -and $auth.password) { $auth.password } else { "gtc@2026" }

                if ($user.ToLower() -eq $validUser.ToLower() -and $pass -eq $validPass) {
                    $token = "gtc_token_" + [System.Guid]::NewGuid().ToString()
                    Send-JsonResponse $response @{
                        success = $true
                        token = $token
                        username = $validUser
                        message = "Login successful!"
                    }
                    continue
                } else {
                    Send-JsonResponse $response @{
                        success = $false
                        error = "Invalid Admin ID or Password. Please try again."
                    } 401
                    continue
                }
            }

            # --- API: Admin Change Password ---
            if ($rawUrl -eq "/api/admin/change-password" -and $httpMethod -eq "POST") {
                $bodyStr = Read-RequestBody $request
                $body = $bodyStr | ConvertFrom-Json

                $newUser = ("" + $body.username).Trim()
                $newPass = ("" + $body.password).Trim()

                if ($newUser.Length -ge 3 -and $newPass.Length -ge 4) {
                    $db = Get-Database
                    if (-not $db.adminAuth) {
                        $db | Add-Member -MemberType NoteProperty -Name "adminAuth" -Value @{} -Force
                    }
                    $db.adminAuth.username = $newUser
                    $db.adminAuth.password = $newPass
                    Save-Database $db

                    Send-JsonResponse $response @{
                        success = $true
                        message = "Admin credentials updated successfully!"
                    }
                    continue
                } else {
                    Send-JsonResponse $response @{
                        success = $false
                        error = "Username must be at least 3 characters and password at least 4 characters."
                    } 400
                    continue
                }
            }

            # --- API: Get Outlets ---
            if ($rawUrl -eq "/api/outlets" -and $httpMethod -eq "GET") {
                $db = Get-Database
                $outlets = @($db.outlets)
                Send-JsonResponse $response $outlets
                continue
            }

            # --- API: Add New Outlet ---
            if ($rawUrl -eq "/api/outlets" -and $httpMethod -eq "POST") {
                $bodyStr = Read-RequestBody $request
                $body = $bodyStr | ConvertFrom-Json

                $name = ("" + $body.name).Trim()
                $code = ("" + $body.code).Trim().ToUpper()
                $city = ("" + $body.city).Trim()
                $location = ("" + $body.location).Trim()

                if ($name.Length -lt 2) {
                    Send-JsonResponse $response @{ error = "Outlet name is required (minimum 2 characters)." } 400
                    continue
                }

                $db = Get-Database
                if (-not $db.outlets) { $db.outlets = @() }

                # Generate clean unique ID
                $slug = ($name.ToLower() -replace '[^a-z0-9]', '_').Trim('_')
                if (-not $slug) { $slug = "outlet" }
                $candidateId = $slug
                $existingIds = @($db.outlets | ForEach-Object { $_.id })
                if ($existingIds -contains $candidateId) {
                    $candidateId = "${slug}_" + ((Get-Date).Ticks % 100000)
                }

                if (-not $code) {
                    $nextNum = ($db.outlets.Count + 1).ToString("D2")
                    $code = "GTC-$nextNum"
                }

                $newOutlet = @{
                    id = $candidateId
                    code = $code
                    name = $name
                    city = if ($city) { $city } else { "Global Tea Cafe" }
                    location = if ($location) { $location } else { "Main Store" }
                    isActive = $true
                    cycleNumber = 1
                    currentSpinsInCycle = 0
                    totalSpinsAllTime = 0
                    cycleWins = @{
                        chai = 0
                        burger = 0
                        pizza = 0
                        off15 = 0
                        off25 = 0
                        miss = 0
                    }
                    stats = @{
                        totalSpins = 0
                        chai = 0
                        burger = 0
                        pizza = 0
                        off15 = 0
                        off25 = 0
                        miss = 0
                        redeemed = 0
                    }
                    createdAt = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
                }

                $db.outlets = @($db.outlets) + @($newOutlet)
                Save-Database $db

                Send-JsonResponse $response @{
                    success = $true
                    message = "Outlet '$name' ($code) added successfully!"
                    outlet = $newOutlet
                }
                continue
            }

            # --- API: Edit Outlet ---
            if ($rawUrl -eq "/api/outlets/edit" -and $httpMethod -eq "POST") {
                $bodyStr = Read-RequestBody $request
                $body = $bodyStr | ConvertFrom-Json

                $outletId = ("" + $body.id).Trim()
                $name = ("" + $body.name).Trim()
                $code = ("" + $body.code).Trim().ToUpper()
                $city = ("" + $body.city).Trim()
                $location = ("" + $body.location).Trim()

                $db = Get-Database
                $outlet = $db.outlets | Where-Object { $_.id -eq $outletId } | Select-Object -First 1

                if (-not $outlet) {
                    Send-JsonResponse $response @{ error = "Outlet not found." } 404
                    continue
                }

                if ($name) { $outlet.name = $name }
                if ($code) { $outlet.code = $code }
                if ($city) { $outlet.city = $city }
                if ($location) { $outlet.location = $location }

                Save-Database $db

                Send-JsonResponse $response @{
                    success = $true
                    message = "Outlet '$($outlet.name)' updated successfully!"
                    outlet = $outlet
                }
                continue
            }

            # --- API: Delete Outlet ---
            if ($rawUrl -eq "/api/outlets/delete" -and $httpMethod -eq "POST") {
                $bodyStr = Read-RequestBody $request
                $body = $bodyStr | ConvertFrom-Json

                $outletId = ("" + $body.id).Trim()
                $db = Get-Database
                $found = $db.outlets | Where-Object { $_.id -eq $outletId } | Select-Object -First 1

                if (-not $found) {
                    Send-JsonResponse $response @{ error = "Outlet not found." } 404
                    continue
                }

                $db.outlets = @($db.outlets | Where-Object { $_.id -ne $outletId })
                Save-Database $db

                Send-JsonResponse $response @{
                    success = $true
                    message = "Outlet deleted successfully!"
                }
                continue
            }

            # --- API: Get Records ---
            if ($rawUrl -eq "/api/records" -and $httpMethod -eq "GET") {
                $db = Get-Database
                $queryOutlet = $request.QueryString["outlet"]
                $records = @($db.records)
                if ($queryOutlet) {
                    $records = @($records | Where-Object { $_.outletId -eq $queryOutlet })
                }
                Send-JsonResponse $response $records
                continue
            }

            # --- API: Customer Spin (Isolated 100-Cycle Quota Engine) ---
            if ($rawUrl -eq "/api/spin" -and $httpMethod -eq "POST") {
                $bodyStr = Read-RequestBody $request
                $body = $bodyStr | ConvertFrom-Json

                $name = ("" + $body.name).Trim()
                $phone = ("" + $body.phone).Trim() -replace "\D", ""
                $outletId = ("" + $body.outletId).Trim()

                if ($phone.Length -eq 12 -and $phone.StartsWith("91")) {
                    $phone = $phone.Substring(2)
                }

                if ($name.Length -lt 2 -or $phone.Length -ne 10 -or [string]::IsNullOrEmpty($outletId)) {
                    Send-JsonResponse $response @{ error = "Invalid customer name, 10-digit phone number, or outlet ID." } 400
                    continue
                }

                $db = Get-Database
                $outlet = $db.outlets | Where-Object { $_.id -eq $outletId } | Select-Object -First 1

                if (-not $outlet) {
                    Send-JsonResponse $response @{ error = "Outlet not found." } 404
                    continue
                }

                # Check if already played today at this outlet
                $todayDate = (Get-Date).ToString("yyyy-MM-dd")
                $existing = $db.records | Where-Object { 
                    $_.phone -eq $phone -and $_.outletId -eq $outletId -and $_.dateStr -eq $todayDate 
                } | Select-Object -First 1

                if ($existing) {
                    Send-JsonResponse $response @{
                        alreadyPlayed = $true
                        message = "You have already participated today at this outlet."
                        record = $existing
                    }
                    continue
                }

                # ISOLATED 100-SPIN CYCLE FOR THIS STORE
                $spinsInCycle = [int]$outlet.currentSpinsInCycle
                if ($spinsInCycle -ge 100) {
                    $outlet.cycleNumber = [int]$outlet.cycleNumber + 1
                    $outlet.currentSpinsInCycle = 0
                    $spinsInCycle = 0
                    $outlet.cycleWins.chai = 0
                    $outlet.cycleWins.burger = 0
                    $outlet.cycleWins.pizza = 0
                    $outlet.cycleWins.off15 = 0
                    $outlet.cycleWins.off25 = 0
                }

                $remainingSpins = 100 - $spinsInCycle
                $remChai   = [Math]::Max(0, 7 - [int]$outlet.cycleWins.chai)
                $remBurger = [Math]::Max(0, 3 - [int]$outlet.cycleWins.burger)
                $remPizza  = [Math]::Max(0, 3 - [int]$outlet.cycleWins.pizza)
                $remOff15  = [Math]::Max(0, 5 - [int]$outlet.cycleWins.off15)
                $remOff25  = [Math]::Max(0, 1 - [int]$outlet.cycleWins.off25)
                $totalWinsRem = $remChai + $remBurger + $remPizza + $remOff15 + $remOff25
                $remMiss = [Math]::Max(0, $remainingSpins - $totalWinsRem)

                $bag = New-Object System.Collections.Generic.List[string]
                for ($i = 0; $i -lt $remChai; $i++)   { $bag.Add("chai") }
                for ($i = 0; $i -lt $remBurger; $i++) { $bag.Add("burger") }
                for ($i = 0; $i -lt $remPizza; $i++)  { $bag.Add("pizza") }
                for ($i = 0; $i -lt $remOff15; $i++)  { $bag.Add("off15") }
                for ($i = 0; $i -lt $remOff25; $i++)  { $bag.Add("off25") }
                for ($i = 0; $i -lt $remMiss; $i++)   { $bag.Add("miss") }

                if ($bag.Count -eq 0) {
                    $wonKey = "miss"
                } else {
                    $rndIndex = (Get-Random -Minimum 0 -Maximum $bag.Count)
                    $wonKey = $bag[$rndIndex]
                }

                # Update Outlet
                $outlet.currentSpinsInCycle = [int]$outlet.currentSpinsInCycle + 1
                $outlet.totalSpinsAllTime   = [int]$outlet.totalSpinsAllTime + 1

                if (-not $outlet.cycleWins) {
                    $outlet | Add-Member -MemberType NoteProperty -Name "cycleWins" -Value @{} -Force
                }
                if ($wonKey -ne "miss") {
                    try {
                        $outlet.cycleWins.$wonKey = [int]$outlet.cycleWins.$wonKey + 1
                    } catch {
                        $outlet.cycleWins | Add-Member -MemberType NoteProperty -Name $wonKey -Value 1 -Force
                    }
                }

                if (-not $outlet.stats) {
                    $outlet | Add-Member -MemberType NoteProperty -Name "stats" -Value @{} -Force
                }
                try {
                    $outlet.stats.$wonKey = [int]$outlet.stats.$wonKey + 1
                } catch {
                    $outlet.stats | Add-Member -MemberType NoteProperty -Name $wonKey -Value 1 -Force
                }
                try {
                    $outlet.stats.totalSpins = [int]$outlet.stats.totalSpins + 1
                } catch {
                    $outlet.stats | Add-Member -MemberType NoteProperty -Name "totalSpins" -Value 1 -Force
                }

                # Unique Coupon Code
                $randAlpha = -join ((65..90) + (48..57) | Get-Random -Count 5 | ForEach-Object { [char]$_ })
                $couponCode = "$($outlet.code)-$randAlpha"

                $prizeInfo = $PRIZE_CONFIG[$wonKey]

                $newRecord = @{
                    id = [System.Guid]::NewGuid().ToString()
                    name = $name
                    phone = $phone
                    outletId = $outlet.id
                    outletCode = $outlet.code
                    outletName = $outlet.name
                    outletCity = $outlet.city
                    prizeKey = $wonKey
                    prizeTitle = $prizeInfo.title
                    prizeType = $prizeInfo.type
                    couponCode = $couponCode
                    isRedeemed = $false
                    redeemedAt = $null
                    redeemedTimeDisplay = $null
                    timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
                    dateStr = $todayDate
                    timeDisplay = (Get-Date).ToString("dd MMM yyyy, hh:mm tt")
                    cycleNumber = $outlet.cycleNumber
                    spinNumberInCycle = $outlet.currentSpinsInCycle
                }

                if (-not $db.records) { $db.records = @() }
                $db.records = @($newRecord) + @($db.records)

                Save-Database $db

                $resData = @{
                    success = $true
                    prizeKey = $wonKey
                    prizeTitle = $prizeInfo.title
                    prizeType = $prizeInfo.type
                    couponCode = $couponCode
                    record = $newRecord
                    cycleStats = @{
                        cycleNumber = $outlet.cycleNumber
                        currentSpinsInCycle = $outlet.currentSpinsInCycle
                        remainingSpinsInCycle = (100 - $outlet.currentSpinsInCycle)
                        cycleWins = $outlet.cycleWins
                    }
                }

                Send-JsonResponse $response $resData
                continue
            }

            # --- API: Mark as Redeemed ---
            if ($rawUrl -eq "/api/redeem" -and $httpMethod -eq "POST") {
                $bodyStr = Read-RequestBody $request
                $body = $bodyStr | ConvertFrom-Json

                $code = ("" + $body.couponCode).Trim().ToUpper()
                $phone = ("" + $body.phone).Trim() -replace "\D", ""

                $db = Get-Database
                $record = $null

                if ($code) {
                    $record = $db.records | Where-Object { $_.couponCode.ToUpper() -eq $code } | Select-Object -First 1
                }
                elseif ($phone) {
                    $record = $db.records | Where-Object { $_.phone -eq $phone -and -not $_.isRedeemed } | Select-Object -First 1
                }

                if (-not $record) {
                    Send-JsonResponse $response @{ error = "No matching unredeemed voucher found for code/phone." } 404
                    continue
                }

                if ($record.prizeKey -eq "miss") {
                    Send-JsonResponse $response @{
                        error = "This voucher was a consolation entry ('Better Luck Next Time') and cannot be redeemed for prizes."
                    } 400
                    continue
                }

                if ($record.isRedeemed) {
                    $redeemedTime = if ($record.redeemedTimeDisplay) { $record.redeemedTimeDisplay } else { $record.redeemedAt }
                    Send-JsonResponse $response @{
                        success = $false
                        alreadyRedeemed = $true
                        message = "This coupon was already redeemed on $redeemedTime"
                        record = $record
                    }
                    continue
                }

                $record.isRedeemed = $true
                $record.redeemedAt = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
                $record | Add-Member -MemberType NoteProperty -Name "redeemedTimeDisplay" -Value ((Get-Date).ToString("dd MMM yyyy, hh:mm tt")) -Force

                $outlet = $db.outlets | Where-Object { $_.id -eq $record.outletId } | Select-Object -First 1
                if ($outlet -and $outlet.stats) {
                    try {
                        $outlet.stats.redeemed = [int]$outlet.stats.redeemed + 1
                    } catch {
                        $outlet.stats | Add-Member -MemberType NoteProperty -Name "redeemed" -Value 1 -Force
                    }
                }

                Save-Database $db

                Send-JsonResponse $response @{
                    success = $true
                    message = "Voucher successfully redeemed!"
                    record = $record
                }
                continue
            }

            # --- API: Reset Outlet Cycle ---
            if ($rawUrl -eq "/api/reset-cycle" -and $httpMethod -eq "POST") {
                $bodyStr = Read-RequestBody $request
                $body = $bodyStr | ConvertFrom-Json

                $outletId = ("" + $body.outletId).Trim()
                $db = Get-Database
                $outlet = $db.outlets | Where-Object { $_.id -eq $outletId } | Select-Object -First 1

                if ($outlet) {
                    $outlet.cycleNumber = [int]$outlet.cycleNumber + 1
                    $outlet.currentSpinsInCycle = 0
                    $outlet.cycleWins.chai = 0
                    $outlet.cycleWins.burger = 0
                    $outlet.cycleWins.pizza = 0
                    $outlet.cycleWins.off15 = 0
                    $outlet.cycleWins.off25 = 0
                    Save-Database $db

                    Send-JsonResponse $response @{ success = $true; message = "Cycle reset successfully for $($outlet.name)"; outlet = $outlet }
                    continue
                }
            }

            Send-JsonResponse $response @{ error = "API Endpoint Not Found" } 404
            continue
        }

        # STATIC FILE SERVING
        $requestPath = $rawUrl.TrimStart('/')
        if ([string]::IsNullOrEmpty($requestPath) -or $requestPath -eq "") {
            $requestPath = "index.html"
        }

        $localFilePath = Join-Path $PSScriptRoot ($requestPath -replace '/', '\')

        if (Test-Path $localFilePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($localFilePath).ToLower()
            $mime = "application/octet-stream"
            if ($mimeTypes.ContainsKey($ext)) {
                $mime = $mimeTypes[$ext]
            }
            $response.ContentType = $mime

            $fileBytes = [System.IO.File]::ReadAllBytes($localFilePath)
            $response.ContentLength64 = $fileBytes.Length
            $response.OutputStream.Write($fileBytes, 0, $fileBytes.Length)
            $response.Close()
        }
        else {
            $response.StatusCode = 404
            $msg = "404 Not Found: $requestPath"
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($msg)
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.Close()
        }
    }
    catch {
        Write-Host "Request error: $_" -ForegroundColor Red
        try {
            $response.StatusCode = 500
            $errBytes = [System.Text.Encoding]::UTF8.GetBytes("500 Server Error: $_")
            $response.ContentLength64 = $errBytes.Length
            $response.OutputStream.Write($errBytes, 0, $errBytes.Length)
            $response.Close()
        } catch {}
    }
}
