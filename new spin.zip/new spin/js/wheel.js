/**
 * Global Tea Cafe - Canvas Lucky Wheel Engine
 * High-definition rendering, realistic physics, needle deflection & sound hooks
 */

class SpinWheel {
  constructor(canvasId, options = {}) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext('2d');

    this.slices = options.slices || [
      { key: 'chai',   label: 'FREE CHAI',    icon: '☕', bg: '#0e4d36', text: '#ffffff' },
      { key: 'burger', label: 'FREE BURGER',  icon: '🍔', bg: '#d97706', text: '#ffffff' },
      { key: 'off15',  label: '15% OFF',      icon: '🏷️', bg: '#1e3a8a', text: '#ffffff' },
      { key: 'pizza',  label: 'FREE PIZZA',   icon: '🍕', bg: '#b91c1c', text: '#ffffff' },
      { key: 'miss',   label: 'TRY AGAIN',    icon: '🍀', bg: '#475569', text: '#ffffff' },
      { key: 'off25',  label: '25% OFF',      icon: '🌟', bg: '#7c3aed', text: '#ffffff' },
      { key: 'coffee', label: 'FREE COFFEE',  icon: '☕', bg: '#065f46', text: '#ffffff' },
      { key: 'off100', label: '100% OFF',     icon: '👑', bg: '#d4af37', text: '#111827' }
    ];

    this.numSlices = this.slices.length;
    this.sliceAngle = (2 * Math.PI) / this.numSlices;

    this.currentAngle = 0; // Current rotation in radians
    this.isSpinning = false;
    this.onTick = options.onTick || (() => {});
    this.onFinish = options.onFinish || (() => {});

    this.lastTickIndex = -1;

    this.initCanvasSize();
    window.addEventListener('resize', () => this.initCanvasSize());
  }

  initCanvasSize() {
    const parent = this.canvas ? this.canvas.parentElement : null;
    let size = 320;

    if (parent && parent.clientWidth > 50) {
      size = Math.min(parent.clientWidth - 20, 420);
    } else {
      const screenW = window.innerWidth || 360;
      size = Math.min(screenW - 40, 400);
    }
    size = Math.max(260, Math.floor(size));

    const dpr = window.devicePixelRatio || 1;

    this.canvas.width = size * dpr;
    this.canvas.height = size * dpr;
    this.canvas.style.width = `${size}px`;
    this.canvas.style.height = `${size}px`;

    this.ctx.setTransform(1, 0, 0, 1, 0, 0);
    this.ctx.scale(dpr, dpr);
    this.displaySize = size;
    this.radius = (size / 2) - 14;
    this.center = size / 2;

    this.draw();
  }

  draw() {
    const ctx = this.ctx;
    const center = this.center;
    const radius = this.radius;

    ctx.clearRect(0, 0, this.displaySize, this.displaySize);

    // Save before rotating
    ctx.save();
    ctx.translate(center, center);
    ctx.rotate(this.currentAngle);

    // 1. Outer Golden Rim Shadow
    ctx.beginPath();
    ctx.arc(0, 0, radius + 8, 0, 2 * Math.PI);
    ctx.fillStyle = '#222';
    ctx.fill();

    // 2. Outer Golden Bezel
    const bezelGrad = ctx.createLinearGradient(-radius, -radius, radius, radius);
    bezelGrad.addColorStop(0, '#f9d976');
    bezelGrad.addColorStop(0.5, '#e5a93b');
    bezelGrad.addColorStop(1, '#9b7126');
    ctx.beginPath();
    ctx.arc(0, 0, radius + 6, 0, 2 * Math.PI);
    ctx.fillStyle = bezelGrad;
    ctx.fill();

    // Inner Dark Ring
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, 2 * Math.PI);
    ctx.fillStyle = '#062217';
    ctx.fill();

    // 3. Draw Slices
    for (let i = 0; i < this.numSlices; i++) {
      const slice = this.slices[i];
      const startAngle = i * this.sliceAngle;
      const endAngle = startAngle + this.sliceAngle;

      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, radius - 2, startAngle, endAngle);
      ctx.closePath();

      ctx.fillStyle = slice.bg;
      ctx.fill();

      // Divider line
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = '#d4af37';
      ctx.stroke();

      // Draw Slice Content
      ctx.save();
      ctx.rotate(startAngle + this.sliceAngle / 2);

      // Icon
      ctx.font = '22px "Segoe UI Emoji", "Apple Color Emoji", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(slice.icon, radius * 0.76, 0);

      // Label text
      ctx.fillStyle = slice.text;
      ctx.font = 'bold 12px "Outfit", "Plus Jakarta Sans", sans-serif';
      ctx.letterSpacing = '1px';
      ctx.shadowColor = 'rgba(0,0,0,0.4)';
      ctx.shadowBlur = 4;
      ctx.fillText(slice.label, radius * 0.46, 0);

      ctx.restore();
    }

    // 4. Rim LED Bulbs / Dots
    const numBulbs = 24;
    for (let b = 0; b < numBulbs; b++) {
      const bAngle = (b * 2 * Math.PI) / numBulbs;
      const bx = (radius + 2) * Math.cos(bAngle);
      const by = (radius + 2) * Math.sin(bAngle);

      ctx.beginPath();
      ctx.arc(bx, by, 3, 0, 2 * Math.PI);
      ctx.fillStyle = b % 2 === 0 ? '#fff5cc' : '#ffffff';
      ctx.shadowColor = '#ffe066';
      ctx.shadowBlur = 5;
      ctx.fill();
    }
    ctx.shadowBlur = 0;

    // 5. Center Hub / Emblem
    const centerGrad = ctx.createRadialGradient(0, 0, 5, 0, 0, 36);
    centerGrad.addColorStop(0, '#fde68a');
    centerGrad.addColorStop(0.5, '#d97706');
    centerGrad.addColorStop(1, '#78350f');

    ctx.beginPath();
    ctx.arc(0, 0, 36, 0, 2 * Math.PI);
    ctx.fillStyle = centerGrad;
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#fff';
    ctx.stroke();

    // Center Inner Disc
    ctx.beginPath();
    ctx.arc(0, 0, 26, 0, 2 * Math.PI);
    ctx.fillStyle = '#0b3b28';
    ctx.fill();

    // Center Tea Emblem
    ctx.font = 'bold 18px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fde68a';
    ctx.fillText('☕', 0, 0);

    ctx.restore();
  }

  /**
   * Spin to land precisely on targetKey
   * @param {string} targetKey - slice key to land on
   * @param {function} onComplete - callback when spin finishes
   */
  spinTo(targetKey, onComplete) {
    if (this.isSpinning) return;
    this.isSpinning = true;

    // Find target slice index
    let targetIndex = this.slices.findIndex(s => s.key === targetKey);
    if (targetIndex === -1) {
      targetIndex = 0; // Default fallback
    }

    // Pointer is at the TOP (angle = 3*Math.PI / 2 or -Math.PI / 2)
    // To land on targetIndex, we calculate the angle where the center of targetIndex points upwards
    const targetSliceCenter = targetIndex * this.sliceAngle + this.sliceAngle / 2;
    
    // In our coordinate system, top is 3*PI/2:
    // (targetSliceCenter + targetAngle) % 2PI = 3*PI/2
    // targetAngle = 3*PI/2 - targetSliceCenter
    const pointerAngle = (3 * Math.PI) / 2;
    let desiredAngle = pointerAngle - targetSliceCenter;

    // Add slight random offset within the slice (+/- 25% of slice width) to feel organic
    const jitter = (Math.random() - 0.5) * (this.sliceAngle * 0.5);
    desiredAngle += jitter;

    // Normalize desiredAngle to be strictly positive and ahead of currentAngle
    const fullRotations = (5 + Math.floor(Math.random() * 3)) * (2 * Math.PI); // 5 to 7 full spins
    const currentNorm = this.currentAngle % (2 * Math.PI);
    let finalAngle = this.currentAngle + fullRotations + ((desiredAngle - currentNorm + 2 * Math.PI) % (2 * Math.PI));

    const startAngle = this.currentAngle;
    const totalDistance = finalAngle - startAngle;
    const duration = 4600; // 4.6 seconds
    const startTime = performance.now();

    // Animate pointer needle
    const needleEl = document.querySelector('.wheel-needle');

    const animate = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Custom smooth easing curve (Quintic Out)
      const ease = 1 - Math.pow(1 - progress, 4.2);
      this.currentAngle = startAngle + totalDistance * ease;

      // Check tick trigger
      const normalizedTop = ((3 * Math.PI / 2) - (this.currentAngle % (2 * Math.PI)) + 4 * Math.PI) % (2 * Math.PI);
      const currentSliceIdx = Math.floor(normalizedTop / this.sliceAngle) % this.numSlices;

      if (currentSliceIdx !== this.lastTickIndex) {
        this.lastTickIndex = currentSliceIdx;
        this.onTick();

        if (needleEl) {
          needleEl.classList.remove('tick-deflect');
          void needleEl.offsetWidth; // Force reflow
          needleEl.classList.add('tick-deflect');
        }
      }

      this.draw();

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        this.isSpinning = false;
        this.currentAngle = finalAngle;
        this.draw();
        const wonSlice = this.slices[targetIndex];
        this.onFinish(wonSlice);
        if (onComplete) onComplete(wonSlice);
      }
    };

    requestAnimationFrame(animate);
  }
}
