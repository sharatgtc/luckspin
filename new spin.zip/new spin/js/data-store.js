/**
 * Global Tea Cafe - Unified Data Store Layer
 * Handles communication with:
 * 1. Local/Network PowerShell REST Server (/api/...)
 * 2. Optional Firebase Cloud Firestore (for instant production multi-outlet cloud sync)
 * 3. LocalStorage fallback (for offline or file:// preview)
 */

const DataStore = (() => {
  const STORAGE_KEY_DB = 'gtc_spin_db';
  const STORAGE_KEY_FIREBASE = 'gtc_firebase_config';
  const SEED_OUTLETS = [{id:'outlet_01',code:'GTC-01',name:'Connaught Place Central',city:'New Delhi',location:'Inner Circle, Block C'},{id:'outlet_02',code:'GTC-02',name:'Koramangala 5th Block',city:'Bengaluru',location:'80 Feet Road'},{id:'outlet_03',code:'GTC-03',name:'Bandra West Linking Rd',city:'Mumbai',location:'Opp. KFC, Linking Road'},{id:'outlet_04',code:'GTC-04',name:'HSR Layout Sector 4',city:'Bengaluru',location:'27th Main Road'},{id:'outlet_05',code:'GTC-05',name:'Cyber Hub Phase 2',city:'Gurugram',location:'DLF Cyber City'},{id:'outlet_06',code:'GTC-06',name:'Indiranagar 100ft Rd',city:'Bengaluru',location:'12th Main Junction'},{id:'outlet_07',code:'GTC-07',name:'Banjara Hills Rd 12',city:'Hyderabad',location:'Near MLA Colony'},{id:'outlet_08',code:'GTC-08',name:'Juhu Tara Road',city:'Mumbai',location:'Near Juhu Beach'},{id:'outlet_09',code:'GTC-09',name:'Khan Market Middle Lane',city:'New Delhi',location:'Shop 42, Khan Market'},{id:'outlet_10',code:'GTC-10',name:'Koregaon Park North Main',city:'Pune',location:'Lane 7, KP'},{id:'outlet_11',code:'GTC-11',name:'Park Street Heritage',city:'Kolkata',location:'18 Park Street'},{id:'outlet_12',code:'GTC-12',name:'Church Street Downtown',city:'Bengaluru',location:'Church Street Blvd'},{id:'outlet_13',code:'GTC-13',name:'Sector 29 Leisure Valley',city:'Gurugram',location:'SCO 14, Sector 29'},{id:'outlet_14',code:'GTC-14',name:'Hauz Khas Village',city:'New Delhi',location:'HKV Lakeside'},{id:'outlet_15',code:'GTC-15',name:'Whitefield ITPL Main Rd',city:'Bengaluru',location:'Ascendas Park Square'},{id:'outlet_16',code:'GTC-16',name:'Powai Hiranandani',city:'Mumbai',location:'Galleria Shopping Mall'},{id:'outlet_17',code:'GTC-17',name:'Jubilee Hills Checkpost',city:'Hyderabad',location:'Road No 36'},{id:'outlet_18',code:'GTC-18',name:'FC Road Deccan Gymkhana',city:'Pune',location:'Fergusson College Rd'},{id:'outlet_19',code:'GTC-19',name:'Sector 18 Atta Market',city:'Noida',location:'Wave Silver Tower'},{id:'outlet_20',code:'GTC-20',name:'C-Scheme Ashok Nagar',city:'Jaipur',location:'Ahinsa Circle'},{id:'outlet_21',code:'GTC-21',name:'Salt Lake Sector 5',city:'Kolkata',location:'RDB Boulevard'},{id:'outlet_22',code:'GTC-22',name:'Anna Nagar 2nd Avenue',city:'Chennai',location:'Roundtana Circle'},{id:'outlet_23',code:'GTC-23',name:'Kalyan Nagar HRBR Layout',city:'Bengaluru',location:'Kammanahalli Main'},{id:'outlet_24',code:'GTC-24',name:'Colaba Causeway',city:'Mumbai',location:'Near Regal Cinema'},{id:'outlet_25',code:'GTC-25',name:'Gachibowli Financial Dist',city:'Hyderabad',location:'Biodiversity Park'},{id:'outlet_26',code:'GTC-26',name:'Vasant Kunj Promenade',city:'New Delhi',location:'Nelson Mandela Marg'},{id:'outlet_27',code:'GTC-27',name:'Sector 35B Piccadilly',city:'Chandigarh',location:'Sector 35 Sub City'},{id:'outlet_28',code:'GTC-28',name:'Hazratganj Heritage',city:'Lucknow',location:'Mahatma Gandhi Marg'},{id:'outlet_29',code:'GTC-29',name:'Viman Nagar Phoenix',city:'Pune',location:'Near Symbiosis Rd'},{id:'outlet_30',code:'GTC-30',name:'Thane Viviana Mall',city:'Thane',location:'Eastern Express Hwy'},{id:'outlet_31',code:'GTC-31',name:'Bespoke Nungambakkam',city:'Chennai',location:'Khader Nawaz Khan Rd'},{id:'outlet_32',code:'GTC-32',name:'Aliganj Kapoorthala',city:'Lucknow',location:'Sector B Aliganj'},{id:'outlet_33',code:'GTC-33',name:'Mall of Asia Byatarayanapura',city:'Bengaluru',location:'Bellary Road'},{id:'outlet_34',code:'GTC-34',name:'Ballygunge Circular Rd',city:'Kolkata',location:'Southern Avenue'},{id:'outlet_35',code:'GTC-35',name:'Lajpat Nagar Central Mkt',city:'New Delhi',location:'Feroze Gandhi Road'},{id:'outlet_36',code:'GTC-36',name:'Andheri West Lokhandwala',city:'Mumbai',location:'Market Complex'},{id:'outlet_37',code:'GTC-37',name:'Kondapur Botanical Garden',city:'Hyderabad',location:'Hitec City Main'},{id:'outlet_38',code:'GTC-38',name:'Aundh ITI Road',city:'Pune',location:'DP Road Corner'},{id:'outlet_39',code:'GTC-39',name:'Sector 62 Electronic City',city:'Noida',location:'Stellar IT Park'},{id:'outlet_40',code:'GTC-40',name:'Malviya Nagar Gaurav Tower',city:'Jaipur',location:'GT Central Mall'},{id:'outlet_41',code:'GTC-41',name:'BTM Layout 2nd Stage',city:'Bengaluru',location:'Outer Ring Road'},{id:'outlet_42',code:'GTC-42',name:'Bandra Kurla Complex (BKC)',city:'Mumbai',location:'Godrej BKC'},{id:'outlet_43',code:'GTC-43',name:'South Extension Part 2',city:'New Delhi',location:'Main Market'},{id:'outlet_44',code:'GTC-44',name:'Kakkanad Infopark',city:'Kochi',location:'Expressway Hub'},{id:'outlet_45',code:'GTC-45',name:'Madapur Cyber Towers',city:'Hyderabad',location:'Image Gardens Lane'},{id:'outlet_46',code:'GTC-46',name:'Baner Balewadi High St',city:'Pune',location:'Cummins India Office Rd'},{id:'outlet_47',code:'GTC-47',name:'Sector 26 Madhya Marg',city:'Chandigarh',location:'Near Grain Market'},{id:'outlet_48',code:'GTC-48',name:'New Town Action Area 1',city:'Kolkata',location:'Axis Mall Complex'},{id:'outlet_49',code:'GTC-49',name:'Velachery Phoenix Marketcity',city:'Chennai',location:'Velachery Main Rd'},{id:'outlet_50',code:'GTC-50',name:'Gomti Nagar Patrakar',city:'Lucknow',location:'Vipin Khand'},{id:'outlet_51',code:'GTC-51',name:'Jayanagar 4th Block',city:'Bengaluru',location:'Complex 11th Main'},{id:'outlet_52',code:'GTC-52',name:'Navi Mumbai Seawoods Grand',city:'Navi Mumbai',location:'Grand Central Mall'},{id:'outlet_53',code:'GTC-53',name:'Noida Sector 104 Starling',city:'Noida',location:'Pathway Market'},{id:'outlet_54',code:'GTC-54',name:'Vaishali Nagar Amrapali',city:'Jaipur',location:'Amrapali Circle'},{id:'outlet_55',code:'GTC-55',name:'Golf Course Extension Rd',city:'Gurugram',location:'AIPL Joy Street'},{id:'outlet_56',code:'GTC-56',name:'Rajouri Garden Main Mkt',city:'New Delhi',location:'Ring Road'},{id:'outlet_57',code:'GTC-57',name:'Electronic City Phase 1',city:'Bengaluru',location:'Neeladri Road'},{id:'outlet_58',code:'GTC-58',name:'Borivali West IC Colony',city:'Mumbai',location:'Holy Cross Road'},{id:'outlet_59',code:'GTC-59',name:'Himayatnagar Street 5',city:'Hyderabad',location:'Liberty Road'},{id:'outlet_60',code:'GTC-60',name:'Wakad Hinjawadi Bridge',city:'Pune',location:'Dattashram Chowk'},{id:'outlet_61',code:'GTC-61',name:'Panampilly Nagar',city:'Kochi',location:'Main Avenue'},{id:'outlet_62',code:'GTC-62',name:'OMR Thoraipakkam',city:'Chennai',location:'Rajiv Gandhi Salai'},{id:'outlet_63',code:'GTC-63',name:'Rajarhat City Centre 2',city:'Kolkata',location:'Action Area II'},{id:'outlet_64',code:'GTC-64',name:'Dwarka Sector 12 City Mall',city:'New Delhi',location:'Ashirwad Chowk'},{id:'outlet_65',code:'GTC-65',name:'Greater Noida Knowledge Park',city:'Greater Noida',location:'Alpha 1 Commercial'},{id:'outlet_66',code:'GTC-66',name:'Indore Vijay Nagar',city:'Indore',location:'Scheme 54 PU 4'},{id:'outlet_67',code:'GTC-67',name:'Bhopal MP Nagar Zone 2',city:'Bhopal',location:'Near DB City Mall'},{id:'outlet_68',code:'GTC-68',name:'Ahmedabad Sindhu Bhavan Rd',city:'Ahmedabad',location:'Bodakdev SBR'},{id:'outlet_69',code:'GTC-69',name:'Surat Piplod VIP Road',city:'Surat',location:'Dumas Road'},{id:'outlet_70',code:'GTC-70',name:'Vadodara Alkapuri',city:'Vadodara',location:'RC Dutt Road'}];

  // Base API URL detection
  const isHttp = window.location.protocol.startsWith('http');
  const apiBase = isHttp ? '' : 'http://localhost:8080';

  let hasServerApi = false;

  // Check if backend API is reachable
  async function testServerApi() {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 1200);
      const res = await fetch(`${apiBase}/api/status`, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (res.ok) {
        hasServerApi = true;
        return true;
      }
    } catch (e) {
      hasServerApi = false;
    }
    return false;
  }

  // LocalStorage Helper (Offline / Fallback)
  function getLocalDB() {
    const raw = localStorage.getItem(STORAGE_KEY_DB);
    if (raw) {
      try { return JSON.parse(raw); } catch (e) {}
    }
    return null;
  }

  function saveLocalDB(db) {
    localStorage.setItem(STORAGE_KEY_DB, JSON.stringify(db));
  }

  // Initialize offline seed if needed
  // Bulletproof Local Database Initialization (starts with clean empty outlets list)
  function ensureLocalDB() {
    let db = getLocalDB();
    if (!db) {
      db = {
        brand: {
          name: 'Global Tea Cafe',
          tagline: 'Where Tea Travels The World',
          logo: 'img/Logo.webp',
          minOrderAmount: 110
        },
        rules: {
          spinsPerCycle: 100,
          quotas: { chai: 7, burger: 3, pizza: 3, off15: 5, off25: 1, miss: 81 }
        },
        outlets: [],
        records: []
      };
      saveLocalDB(db);
    }
    if (!db.outlets) db.outlets = [];
    if (!db.records) db.records = [];
    return db;
  }

  // --- Core API Methods ---

  async function getOutlets() {
    if (await testServerApi()) {
      try {
        const res = await fetch(`${apiBase}/api/outlets`);
        if (res.ok) return await res.json();
      } catch (e) { console.error('API Error:', e); }
    }
    // Fallback
    const db = await ensureLocalDB();
    return db ? db.outlets || [] : [];
  }

  async function getOutlet(outletId) {
    const outlets = await getOutlets();
    return outlets.find(o => o.id === outletId || o.code === outletId) || outlets[0];
  }

  async function performSpin({ name, phone, outletId }) {
    if (await testServerApi()) {
      try {
        const res = await fetch(`${apiBase}/api/spin`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, phone, outletId })
        });
        const data = await res.json();
        return data;
      } catch (e) {
        console.error('Spin API error:', e);
      }
    }

    // Client-side Isolated 100-Cycle Quota Fallback
    const db = await ensureLocalDB() || { outlets: [], records: [] };
    let outlet = db.outlets.find(o => o.id === outletId) || db.outlets[0];
    if (!outlet) {
      return { error: 'Outlet not found' };
    }

    const cleanPhone = phone.replace(/\D/g, '').slice(-10);
    const today = new Date().toISOString().slice(0, 10);

    // Check already played today
    const existing = (db.records || []).find(r => r.phone === cleanPhone && r.outletId === outlet.id && r.dateStr === today);
    if (existing) {
      return { alreadyPlayed: true, message: 'You have already participated today at this outlet.', record: existing };
    }

    // Isolated 100-spin cycle calculation
    if (!outlet.cycleNumber) outlet.cycleNumber = 1;
    if (typeof outlet.currentSpinsInCycle !== 'number') outlet.currentSpinsInCycle = 0;
    if (!outlet.cycleWins) outlet.cycleWins = { chai: 0, burger: 0, pizza: 0, off15: 0, off25: 0 };
    if (!outlet.stats) outlet.stats = { chai: 0, burger: 0, pizza: 0, off15: 0, off25: 0, miss: 0, redeemed: 0 };

    if (outlet.currentSpinsInCycle >= 100) {
      outlet.cycleNumber += 1;
      outlet.currentSpinsInCycle = 0;
      outlet.cycleWins = { chai: 0, burger: 0, pizza: 0, off15: 0, off25: 0 };
    }

    const remainingSpins = 100 - outlet.currentSpinsInCycle;
    const remChai   = Math.max(0, 7 - (outlet.cycleWins.chai || 0));
    const remBurger = Math.max(0, 3 - (outlet.cycleWins.burger || 0));
    const remPizza  = Math.max(0, 3 - (outlet.cycleWins.pizza || 0));
    const remOff15  = Math.max(0, 5 - (outlet.cycleWins.off15 || 0));
    const remOff25  = Math.max(0, 1 - (outlet.cycleWins.off25 || 0));
    const remWins   = remChai + remBurger + remPizza + remOff15 + remOff25;
    const remMiss   = Math.max(0, remainingSpins - remWins);

    const bag = [];
    for (let i = 0; i < remChai; i++) bag.push('chai');
    for (let i = 0; i < remBurger; i++) bag.push('burger');
    for (let i = 0; i < remPizza; i++) bag.push('pizza');
    for (let i = 0; i < remOff15; i++) bag.push('off15');
    for (let i = 0; i < remOff25; i++) bag.push('off25');
    for (let i = 0; i < remMiss; i++) bag.push('miss');

    const wonKey = bag.length > 0 ? bag[Math.floor(Math.random() * bag.length)] : 'miss';

    // Update stats
    outlet.currentSpinsInCycle += 1;
    outlet.totalSpinsAllTime = (outlet.totalSpinsAllTime || 0) + 1;
    if (wonKey !== 'miss') {
      outlet.cycleWins[wonKey] = (outlet.cycleWins[wonKey] || 0) + 1;
    }
    outlet.stats[wonKey] = (outlet.stats[wonKey] || 0) + 1;

    // Prize titles
    const titles = {
      chai: { title: 'Free Chai', type: 'item' },
      burger: { title: 'Free Burger', type: 'item' },
      pizza: { title: 'Free Pizza', type: 'item' },
      off15: { title: '15% OFF', type: 'discount' },
      off25: { title: '25% OFF', type: 'discount' },
      miss: { title: 'Better Luck Next Time', type: 'none' }
    };
    const prizeMeta = titles[wonKey] || titles.miss;

    // Coupon Code
    const randAlpha = Math.random().toString(36).substring(2, 7).toUpperCase();
    const couponCode = `${outlet.code}-${randAlpha}`;

    const newRecord = {
      id: 'rec_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      name,
      phone: cleanPhone,
      outletId: outlet.id,
      outletCode: outlet.code,
      outletName: outlet.name,
      outletCity: outlet.city,
      prizeKey: wonKey,
      prizeTitle: prizeMeta.title,
      prizeType: prizeMeta.type,
      couponCode,
      isRedeemed: false,
      redeemedAt: null,
      timestamp: new Date().toISOString(),
      dateStr: today,
      timeDisplay: new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true }),
      cycleNumber: outlet.cycleNumber,
      spinNumberInCycle: outlet.currentSpinsInCycle
    };

    if (!db.records) db.records = [];
    db.records.unshift(newRecord);
    saveLocalDB(db);

    return {
      success: true,
      prizeKey: wonKey,
      prizeTitle: prizeMeta.title,
      prizeType: prizeMeta.type,
      couponCode,
      record: newRecord,
      cycleStats: {
        cycleNumber: outlet.cycleNumber,
        currentSpinsInCycle: outlet.currentSpinsInCycle,
        remainingSpinsInCycle: 100 - outlet.currentSpinsInCycle,
        cycleWins: outlet.cycleWins
      }
    };
  }

  async function getRecords(outletFilter = '') {
    if (await testServerApi()) {
      try {
        const url = outletFilter ? `${apiBase}/api/records?outlet=${encodeURIComponent(outletFilter)}` : `${apiBase}/api/records`;
        const res = await fetch(url);
        if (res.ok) return await res.json();
      } catch (e) { console.error('Get records API error:', e); }
    }

    const db = await ensureLocalDB();
    if (!db || !db.records) return [];
    if (outletFilter) {
      return db.records.filter(r => r.outletId === outletFilter);
    }
    return db.records;
  }

  async function redeemCoupon(couponCodeOrPhone) {
    if (await testServerApi()) {
      try {
        const isCode = couponCodeOrPhone.includes('-');
        const payload = isCode ? { couponCode: couponCodeOrPhone } : { phone: couponCodeOrPhone };
        const res = await fetch(`${apiBase}/api/redeem`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        return await res.json();
      } catch (e) {
        console.error('Redeem API error:', e);
      }
    }

    // LocalStorage Fallback
    const db = await ensureLocalDB();
    if (!db || !db.records) return { error: 'No records found' };

    const search = couponCodeOrPhone.trim().toUpperCase();
    const isCode = search.includes('-');
    const record = db.records.find(r => isCode ? r.couponCode.toUpperCase() === search : r.phone === search && !r.isRedeemed);

    if (!record) {
      return { error: 'Voucher not found for code / phone number.' };
    }

    if (record.isRedeemed) {
      return {
        alreadyRedeemed: true,
        message: `This coupon was already redeemed on ${record.redeemedTimeDisplay || record.redeemedAt}`,
        record
      };
    }

    record.isRedeemed = true;
    record.redeemedAt = new Date().toISOString();
    record.redeemedTimeDisplay = new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true });

    const outlet = db.outlets.find(o => o.id === record.outletId);
    if (outlet) {
      outlet.stats.redeemed = (outlet.stats.redeemed || 0) + 1;
    }

    saveLocalDB(db);
    return { success: true, message: 'Voucher successfully redeemed!', record };
  }

  async function resetCycle(outletId) {
    if (await testServerApi()) {
      try {
        const res = await fetch(`${apiBase}/api/reset-cycle`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ outletId })
        });
        return await res.json();
      } catch (e) { console.error('Reset cycle error:', e); }
    }

    const db = await ensureLocalDB();
    const outlet = db.outlets.find(o => o.id === outletId);
    if (outlet) {
      outlet.cycleNumber = (outlet.cycleNumber || 1) + 1;
      outlet.currentSpinsInCycle = 0;
      outlet.cycleWins = { chai: 0, burger: 0, pizza: 0, off15: 0, off25: 0 };
      saveLocalDB(db);
      return { success: true, message: `Cycle reset for ${outlet.name}`, outlet };
    }
    return { error: 'Outlet not found' };
  }

  const AUTH_STORAGE_KEY = 'gtc_admin_auth';

  async function adminLogin(username, password) {
    if (await testServerApi()) {
      try {
        const res = await fetch(`${apiBase}/api/admin/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (data.success) {
          sessionStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(data));
          localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(data));
        }
        return data;
      } catch (e) {
        console.error('Login error:', e);
      }
    }

    // Local fallback
    const db = await ensureLocalDB();
    const validUser = (db.adminAuth && db.adminAuth.username) || 'admin';
    const validPass = (db.adminAuth && db.adminAuth.password) || 'gtc@2026';

    if (username.trim().toLowerCase() === validUser.toLowerCase() && password.trim() === validPass) {
      const data = { success: true, token: 'local_token_' + Date.now(), username: validUser };
      sessionStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(data));
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(data));
      return data;
    } else {
      return { success: false, error: 'Invalid Admin ID or Password. Please try again.' };
    }
  }

  function isAdminLoggedIn() {
    const raw = sessionStorage.getItem(AUTH_STORAGE_KEY) || localStorage.getItem(AUTH_STORAGE_KEY);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        return !!parsed.token;
      } catch (e) {}
    }
    return false;
  }

  function adminLogout() {
    sessionStorage.removeItem(AUTH_STORAGE_KEY);
    localStorage.removeItem(AUTH_STORAGE_KEY);
  }

  async function adminChangePassword(username, password) {
    if (await testServerApi()) {
      try {
        const res = await fetch(`${apiBase}/api/admin/change-password`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password })
        });
        return await res.json();
      } catch (e) { console.error('Change password error:', e); }
    }

    const db = await ensureLocalDB();
    if (!db.adminAuth) db.adminAuth = {};
    db.adminAuth.username = username;
    db.adminAuth.password = password;
    saveLocalDB(db);
    return { success: true, message: 'Admin credentials updated successfully!' };
  }

  // --- Outlet Management CRUD ---

  async function createOutlet(outletData) {
    if (await testServerApi()) {
      try {
        const res = await fetch(`${apiBase}/api/outlets`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(outletData)
        });
        return await res.json();
      } catch (e) {
        console.error('Create outlet API error:', e);
      }
    }

    // Local fallback
    const db = ensureLocalDB();
    const name = (outletData.name || '').trim();
    const slug = name.toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/^_+|_+$/g, '') || 'outlet';
    let id = slug;
    if (db.outlets.some(o => o.id === id)) {
      id = `${slug}_${Date.now() % 100000}`;
    }
    const code = (outletData.code || `GTC-${String(db.outlets.length + 1).padStart(2, '0')}`).toUpperCase();

    const newOutlet = {
      id,
      code,
      name,
      city: outletData.city || 'Global Tea Cafe',
      location: outletData.location || 'Main Store',
      isActive: true,
      cycleNumber: 1,
      currentSpinsInCycle: 0,
      totalSpinsAllTime: 0,
      cycleWins: { chai: 0, burger: 0, pizza: 0, off15: 0, off25: 0, miss: 0 },
      stats: { totalSpins: 0, chaiWins: 0, burgerWins: 0, pizzaWins: 0, off15Wins: 0, off25Wins: 0, missCount: 0, redeemed: 0 },
      createdAt: new Date().toISOString()
    };

    db.outlets.push(newOutlet);
    saveLocalDB(db);
    return { success: true, message: `Outlet '${name}' created successfully!`, outlet: newOutlet };
  }

  async function updateOutlet(outletData) {
    if (await testServerApi()) {
      try {
        const res = await fetch(`${apiBase}/api/outlets/edit`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(outletData)
        });
        return await res.json();
      } catch (e) {
        console.error('Update outlet API error:', e);
      }
    }

    // Local fallback
    const db = ensureLocalDB();
    const outlet = db.outlets.find(o => o.id === outletData.id);
    if (!outlet) return { error: 'Outlet not found' };

    if (outletData.name) outlet.name = outletData.name.trim();
    if (outletData.code) outlet.code = outletData.code.trim().toUpperCase();
    if (outletData.city) outlet.city = outletData.city.trim();
    if (outletData.location) outlet.location = outletData.location.trim();

    saveLocalDB(db);
    return { success: true, message: `Outlet '${outlet.name}' updated!`, outlet };
  }

  async function deleteOutlet(outletId) {
    if (await testServerApi()) {
      try {
        const res = await fetch(`${apiBase}/api/outlets/delete`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: outletId })
        });
        return await res.json();
      } catch (e) {
        console.error('Delete outlet API error:', e);
      }
    }

    // Local fallback
    const db = ensureLocalDB();
    db.outlets = db.outlets.filter(o => o.id !== outletId);
    saveLocalDB(db);
    return { success: true, message: 'Outlet deleted successfully!' };
  }

  return {
    testServerApi,
    getOutlets,
    getOutlet,
    createOutlet,
    updateOutlet,
    deleteOutlet,
    performSpin,
    getRecords,
    redeemCoupon,
    resetCycle,
    ensureLocalDB,
    adminLogin,
    isAdminLoggedIn,
    adminLogout,
    adminChangePassword
  };
})();
