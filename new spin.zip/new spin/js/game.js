/**
 * Global Tea Cafe - Customer Spin Game Controller
 */

document.addEventListener('DOMContentLoaded', async () => {
  const REDIRECT_URL = 'https://globalteacafe.com';

  const DEFAULT_OUTLET = {
    id: 'outlet_01',
    code: 'GTC-01',
    name: 'Connaught Place Central',
    city: 'New Delhi',
    location: 'Inner Circle, Block C'
  };

  let currentOutlet = DEFAULT_OUTLET;
  let allOutlets = [];
  let spinWheel = null;
  let currentSpinResult = null;

  // UI Elements
  const outletBadge = document.getElementById('outletBadge');
  const outletNameDisplay = document.getElementById('outletNameDisplay');
  const outletLocationDisplay = document.getElementById('outletLocationDisplay');
  const customerForm = document.getElementById('customerForm');
  const inputName = document.getElementById('customerName');
  const inputPhone = document.getElementById('customerPhone');
  const btnStartSpin = document.getElementById('btnStartSpin');
  const formSection = document.getElementById('formSection');
  const wheelSection = document.getElementById('wheelSection');
  const spinTriggerBtn = document.getElementById('spinTriggerBtn');
  const voucherModal = document.getElementById('voucherModal');
  const tcModal = document.getElementById('tcModal');
  const outletSelectorModal = document.getElementById('outletSelectorModal');
  const soundToggleBtn = document.getElementById('soundToggleBtn');

  // Initialize Sound button state
  if (soundToggleBtn) {
    soundToggleBtn.addEventListener('click', () => {
      const isMuted = SoundFX.toggleMute();
      soundToggleBtn.innerHTML = isMuted ? '🔇' : '🔊';
      soundToggleBtn.title = isMuted ? 'Unmute Sound' : 'Mute Sound';
    });
  }

  // Load Outlets and Determine Current Outlet
  try {
    allOutlets = await DataStore.getOutlets();
    if (!allOutlets || allOutlets.length === 0) {
      currentOutlet = null;
      if (outletBadge) outletBadge.textContent = 'PENDING';
      if (outletNameDisplay) outletNameDisplay.textContent = 'Global Tea Cafe';
      if (outletLocationDisplay) outletLocationDisplay.textContent = 'No outlets added yet. Please add a store in Admin Panel.';
      if (btnStartSpin) {
        btnStartSpin.disabled = true;
        btnStartSpin.textContent = 'Store Setup Needed in Admin Panel';
      }
      return;
    }

    const urlParams = new URLSearchParams(window.location.search);
    let outletParam = urlParams.get('outlet') || urlParams.get('store');

    if (outletParam) {
      outletParam = outletParam.trim().toLowerCase();
      // Match by id or code
      const found = allOutlets.find(o => 
        (o.id && o.id.toLowerCase() === outletParam) || 
        (o.code && o.code.toLowerCase() === outletParam.toUpperCase()) ||
        (o.id && o.id.toLowerCase() === `outlet_${outletParam.padStart(2, '0')}`)
      );
      if (found) currentOutlet = found;
      else currentOutlet = allOutlets[0];
    } else {
      currentOutlet = allOutlets[0];
    }

    updateOutletUI();
  } catch (err) {
    console.warn('Failed to load outlets list:', err);
  }

  function updateOutletUI() {
    if (!currentOutlet) currentOutlet = DEFAULT_OUTLET;
    if (outletBadge) outletBadge.textContent = currentOutlet.code || 'GTC-01';
    if (outletNameDisplay) outletNameDisplay.textContent = currentOutlet.name || 'Connaught Place Central';
    if (outletLocationDisplay) outletLocationDisplay.textContent = `${currentOutlet.location || 'Inner Circle'}, ${currentOutlet.city || 'New Delhi'}`;
  }

  // Initialize Canvas Spin Wheel safely
  try {
    spinWheel = new SpinWheel('wheelCanvas', {
      onTick: () => {
        SoundFX.tick();
      },
      onFinish: (wonSlice) => {
        handleSpinCompletion(wonSlice);
      }
    });
  } catch (err) {
    console.error('Error creating spin wheel:', err);
  }

  // Switch to Wheel View Function
  function switchToWheelView(name, spinRes) {
    currentSpinResult = spinRes;

    if (formSection) formSection.style.display = 'none';
    if (wheelSection) {
      wheelSection.style.display = 'block';

      // Re-init canvas size now that container is visible and measurable
      setTimeout(() => {
        if (spinWheel) {
          spinWheel.initCanvasSize();
        }
      }, 40);
    }

    const playerGreeting = document.getElementById('playerGreeting');
    if (playerGreeting) {
      playerGreeting.textContent = `Welcome, ${name}! Tap "SPIN NOW" below to win!`;
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Handle Customer Details Form Submission
  if (customerForm) {
    customerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      SoundFX.click();

      const name = inputName.value.trim();
      let phone = inputPhone.value.trim().replace(/\D/g, '');

      if (phone.length === 12 && phone.startsWith('91')) {
        phone = phone.slice(2);
      }

      if (name.length < 2) {
        showToast('Please enter your full name', 'error');
        inputName.focus();
        return;
      }

      if (phone.length !== 10 || !/^[6-9]\d{9}$/.test(phone)) {
        showToast('Please enter a valid 10-digit mobile number', 'error');
        inputPhone.focus();
        return;
      }

      const tcChecked = document.getElementById('agreeTerms').checked;
      if (!tcChecked) {
        showToast('Please agree to the Terms & Conditions', 'warning');
        return;
      }

      btnStartSpin.disabled = true;
      btnStartSpin.innerHTML = '<span class="spinner"></span> Verifying...';

      let res = null;
      try {
        if (!currentOutlet) currentOutlet = DEFAULT_OUTLET;

        res = await DataStore.performSpin({
          name,
          phone,
          outletId: currentOutlet.id
        });
      } catch (err) {
        console.error('Spin API call failed:', err);
      } finally {
        btnStartSpin.disabled = false;
        btnStartSpin.innerHTML = 'Proceed to Spin Wheel 🎯';
      }

      if (!res) {
        showToast('Could not verify connection. Please try again.', 'error');
        return;
      }

      // If customer has already played today: Directly show their active voucher
      if (res.alreadyPlayed) {
        showToast('You already participated today at this store! Showing your voucher.', 'info');
        showVoucherModal(res.record);
        return;
      }

      if (res.error) {
        showToast(res.error, 'error');
        return;
      }

      // Successful new spin: Show wheel!
      switchToWheelView(name, res);
    });
  }

  // Spin Trigger Button Click
  if (spinTriggerBtn) {
    spinTriggerBtn.addEventListener('click', () => {
      if (spinWheel && spinWheel.isSpinning) return;
      SoundFX.click();

      spinTriggerBtn.disabled = true;
      spinTriggerBtn.classList.add('spinning');
      spinTriggerBtn.innerHTML = 'SPINNING...';

      // Target prize determined by server/quota engine
      const targetPrizeKey = currentSpinResult ? currentSpinResult.prizeKey : 'chai';

      spinWheel.spinTo(targetPrizeKey, () => {
        spinTriggerBtn.disabled = false;
        spinTriggerBtn.classList.remove('spinning');
        spinTriggerBtn.innerHTML = 'SPIN NOW 🎁';
      });
    });
  }

  // Handle Spin Completion
  function handleSpinCompletion(wonSlice) {
    if (!currentSpinResult) return;

    const isMiss = currentSpinResult.prizeKey === 'miss';

    if (isMiss) {
      SoundFX.consolation();
    } else {
      SoundFX.win();
      triggerConfetti();
    }

    setTimeout(() => {
      showVoucherModal(currentSpinResult.record);
    }, 600);
  }

  // Show Winning Voucher Modal
  function showVoucherModal(record) {
    if (!record) return;

    const isMiss = record.prizeKey === 'miss';
    const modalContent = document.getElementById('voucherContent');

    const couponBadgeColor = {
      chai: '#0e4d36',
      burger: '#d97706',
      pizza: '#dc2626',
      off15: '#2563eb',
      off25: '#7c3aed',
      coffee: '#065f46',
      off100: '#d4af37',
      miss: '#64748b'
    }[record.prizeKey] || '#0e4d36';

    const iconMap = {
      chai: '☕',
      burger: '🍔',
      pizza: '🍕',
      off15: '🏷️',
      off25: '🌟',
      coffee: '☕',
      off100: '👑',
      miss: '🍀'
    };

    modalContent.innerHTML = `
      <div class="voucher-card ${isMiss ? 'is-miss' : 'is-win'}">
        <div class="voucher-header">
          <img src="img/Logo.webp" alt="Global Tea Cafe" class="voucher-logo">
          <div class="voucher-store-tag">📍 ${record.outletName} (${record.outletCode})</div>
        </div>

        <div class="voucher-body">
          <div class="voucher-icon-badge" style="background:${couponBadgeColor};">
            ${iconMap[record.prizeKey] || '🎁'}
          </div>

          ${isMiss ? `
            <h2 class="voucher-title miss-title">Better Luck Next Time!</h2>
            <p class="voucher-subtitle">Thank you for visiting! Enjoy a piping hot cup of tea & spin again tomorrow.</p>
          ` : `
            <div class="win-tag">CONGRATULATIONS!</div>
            <h2 class="voucher-title win-title">YOU WON ${record.prizeTitle.toUpperCase()}</h2>
            <p class="voucher-subtitle">Show this voucher code at the billing counter to claim your reward.</p>
          `}

          ${!isMiss ? `
            <div class="coupon-code-box">
              <span class="code-label">YOUR VOUCHER CODE</span>
              <div class="code-text" id="voucherCodeText">${record.couponCode}</div>
              <button class="btn-copy-code" onclick="copyVoucherCode('${record.couponCode}')" title="Copy Code">📋 Copy</button>
            </div>
          ` : ''}

          <div class="voucher-details">
            <div class="detail-row">
              <span class="detail-label">Customer Name:</span>
              <span class="detail-value">${record.name}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Mobile Number:</span>
              <span class="detail-value">+91 ${record.phone}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Spin Time:</span>
              <span class="detail-value">${record.timeDisplay || record.dateStr || 'Today'}</span>
            </div>
            ${!isMiss ? `
              <div class="detail-row">
                <span class="detail-label">Validity:</span>
                <span class="detail-value text-success font-bold">Valid for 7 Days</span>
              </div>
            ` : ''}
          </div>

          <!-- Highlighted T&C requirements -->
          <div class="voucher-tc-box">
            <div class="tc-title">📌 Key Terms & Conditions:</div>
            <ul>
              <li><strong>Min Bill:</strong> Valid on orders of <strong>₹110 or above</strong>.</li>
              <li><strong>Location:</strong> Spin is valid <strong>ONLY</strong> when played at billing counter or dine-in table.</li>
              <li><strong>Redemption:</strong> Free items (Tea, Coffee, Burger, Pizza) can be redeemed on your <strong>NEXT visit</strong>.</li>
              <li>Show this code to cashier before bill generation.</li>
            </ul>
          </div>
        </div>

        <div class="voucher-footer">
          ${!isMiss ? `
            <button class="btn-action btn-whatsapp" onclick="shareOnWhatsApp('${record.couponCode}', '${record.prizeTitle}', '${record.outletName}')">
              <span>💬</span> Share on WhatsApp
            </button>
          ` : ''}
          <button class="btn-action btn-close-voucher" onclick="closeVoucherModal()">Close</button>
        </div>
      </div>
    `;

    voucherModal.style.display = 'flex';
  }

  // Confetti Particle Burst
  function triggerConfetti() {
    if (typeof confetti === 'function') {
      confetti({
        particleCount: 90,
        spread: 75,
        origin: { y: 0.6 },
        colors: ['#0e4d36', '#d4af37', '#f9d976', '#dc2626', '#2563eb']
      });
      setTimeout(() => {
        confetti({
          particleCount: 50,
          angle: 60,
          spread: 60,
          origin: { x: 0 },
          colors: ['#d4af37', '#0e4d36']
        });
        confetti({
          particleCount: 50,
          angle: 120,
          spread: 60,
          origin: { x: 1 },
          colors: ['#d4af37', '#0e4d36']
        });
      }, 250);
    }
  }

  // Toast Notification
  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast-msg toast-${type}`;
    toast.innerHTML = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add('visible'), 10);
    setTimeout(() => {
      toast.classList.remove('visible');
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  // Global Helper Functions exposed to window
  // When voucher modal is closed, redirect immediately to globalteacafe.com
  window.closeVoucherModal = () => {
    if (voucherModal) voucherModal.style.display = 'none';
    window.location.href = REDIRECT_URL;
  };

  // Close modal when tapping backdrop outside dialog
  if (voucherModal) {
    voucherModal.addEventListener('click', (e) => {
      if (e.target === voucherModal) {
        window.closeVoucherModal();
      }
    });
  }

  window.showVoucherModal = showVoucherModal;

  window.backToFormView = () => {
    if (wheelSection) wheelSection.style.display = 'none';
    if (formSection) formSection.style.display = 'block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  window.copyVoucherCode = (code) => {
    navigator.clipboard.writeText(code).then(() => {
      showToast('Coupon code copied to clipboard! 📋', 'success');
    }).catch(() => {
      showToast(`Coupon code: ${code}`, 'info');
    });
  };

  window.shareOnWhatsApp = (code, prize, outlet) => {
    const text = encodeURIComponent(`🎉 Woohoo! I just won *${prize}* at *Global Tea Cafe (${outlet})*!\nMy voucher code is: *${code}* ☕🍔🍕\nValid on orders above ₹110.`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  window.openTcModal = () => {
    if (tcModal) tcModal.style.display = 'flex';
  };

  window.closeTcModal = () => {
    if (tcModal) tcModal.style.display = 'none';
  };

  window.openOutletSelector = () => {
    const listEl = document.getElementById('outletListSearch');
    if (!listEl) return;
    listEl.innerHTML = allOutlets.map(o => `
      <div class="outlet-picker-item ${currentOutlet && currentOutlet.id === o.id ? 'active' : ''}" onclick="selectOutlet('${o.id}')">
        <div class="outlet-picker-code">${o.code}</div>
        <div class="outlet-picker-details">
          <div class="outlet-picker-name">${o.name}</div>
          <div class="outlet-picker-loc">${o.location}, ${o.city}</div>
        </div>
        <span class="outlet-picker-arrow">➔</span>
      </div>
    `).join('');
    outletSelectorModal.style.display = 'flex';
  };

  window.closeOutletSelector = () => {
    outletSelectorModal.style.display = 'none';
  };

  window.selectOutlet = (outletId) => {
    const found = allOutlets.find(o => o.id === outletId);
    if (found) {
      currentOutlet = found;
      updateOutletUI();
      // Update URL query string without reloading
      const url = new URL(window.location.href);
      url.searchParams.set('outlet', found.id);
      window.history.replaceState({}, '', url.toString());
      closeOutletSelector();
      showToast(`Selected outlet: ${found.name}`, 'success');
    }
  };

  window.filterOutletList = (query) => {
    const q = query.toLowerCase().trim();
    const items = document.querySelectorAll('.outlet-picker-item');
    items.forEach(el => {
      const text = el.textContent.toLowerCase();
      el.style.display = text.includes(q) ? 'flex' : 'none';
    });
  };
});
