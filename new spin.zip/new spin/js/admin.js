/**
 * Global Tea Cafe - Master Admin Panel Controller
 * Handles 70 Outlets, Customer CRM, Isolated 100-Cycle Quota Engine, CSV Export & Cashier Terminal
 */

document.addEventListener('DOMContentLoaded', async () => {
  let allOutlets = [];
  let allRecords = [];
  let activeTab = 'overview';
  let serverStatus = null;
  let pollInterval = null;

  // Authentication Gateway Check
  const loginOverlay = document.getElementById('adminLoginOverlay');
  const loginForm = document.getElementById('adminLoginForm');
  const loginErrorMsg = document.getElementById('loginErrorMsg');

  function checkAuthAndInit() {
    if (!DataStore.isAdminLoggedIn()) {
      if (loginOverlay) loginOverlay.style.display = 'flex';
      if (pollInterval) clearInterval(pollInterval);
      return false;
    } else {
      if (loginOverlay) loginOverlay.style.display = 'none';
      startAdminSession();
      return true;
    }
  }

  // Handle Login Submission
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const user = document.getElementById('adminUsername').value.trim();
      const pass = document.getElementById('adminPassword').value.trim();
      const btnSubmit = document.getElementById('btnLoginSubmit');

      if (loginErrorMsg) loginErrorMsg.style.display = 'none';
      if (btnSubmit) {
        btnSubmit.disabled = true;
        btnSubmit.textContent = 'Verifying Credentials...';
      }

      const res = await DataStore.adminLogin(user, pass);

      if (btnSubmit) {
        btnSubmit.disabled = false;
        btnSubmit.textContent = 'Sign In to Admin Dashboard ➔';
      }

      if (res && res.success) {
        if (loginOverlay) loginOverlay.style.display = 'none';
        showAdminToast('Welcome, Admin! Login successful. 🔓', 'success');
        startAdminSession();
      } else {
        if (loginErrorMsg) {
          loginErrorMsg.textContent = (res && res.error) ? res.error : 'Invalid Admin ID or Password.';
          loginErrorMsg.style.display = 'block';
        }
      }
    });
  }

  async function startAdminSession() {
    await checkServerStatus();
    await loadData();

    if (!pollInterval) {
      pollInterval = setInterval(async () => {
        if (DataStore.isAdminLoggedIn()) {
          await loadData(false);
        }
      }, 5000);
    }
  }

  // Tab Switching
  setupTabs();

  // Setup Search and Filters
  setupFilters();

  // Setup Cashier Terminal
  setupCashierTerminal();

  // Setup Change Credentials Form
  setupSettingsForm();

  // Setup Add / Edit Outlet Modal Form
  setupOutletModalForm();

  // Initial Auth Check
  checkAuthAndInit();

  // --- Core Data Loading ---

  async function checkServerStatus() {
    const statusPill = document.getElementById('serverStatusPill');
    const networkHostText = document.getElementById('networkHostText');

    try {
      const res = await fetch('api/status');
      if (res.ok) {
        serverStatus = await res.json();
        if (statusPill) statusPill.innerHTML = '<span class="status-dot"></span> Server Online';
        if (networkHostText && serverStatus.localIP) {
          networkHostText.textContent = `http://${serverStatus.localIP}:${serverStatus.port || 8080}`;
        }
        return;
      }
    } catch (e) {}

    // Fallback info
    if (statusPill) statusPill.innerHTML = '<span class="status-dot" style="background:#f59e0b"></span> Browser Sync';
    if (networkHostText) {
      networkHostText.textContent = window.location.origin;
    }
  }

  async function loadData(showLoader = true) {
    try {
      allOutlets = await DataStore.getOutlets();
      allRecords = await DataStore.getRecords();

      renderMetrics();
      renderOverviewFeed();
      renderRecordsTable();
      renderOutletsGrid();
      renderQuotaMonitor();
      populateStoreFilterDropdown();
    } catch (err) {
      console.error('Failed to load admin data:', err);
    }
  }

  function renderOverviewFeed() {
    const tbody = document.getElementById('overviewRecentTableBody');
    if (!tbody) return;

    const recent = allRecords.slice(0, 10);
    if (recent.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:30px; color:#94a3b8;">No customer activity yet. As customers spin at any outlet, entries will appear here in real time!</td></tr>`;
      return;
    }

    tbody.innerHTML = recent.map(r => {
      const badgeClass = {
        chai: 'badge-chai', burger: 'badge-burger', pizza: 'badge-pizza',
        off15: 'badge-15off', off25: 'badge-25off', miss: 'badge-miss'
      }[r.prizeKey] || 'badge-miss';
      const isMiss = r.prizeKey === 'miss';

      return `
        <tr>
          <td><span style="font-size:0.75rem; color:#64748b;">${r.timeDisplay || r.dateStr || ''}</span></td>
          <td><strong>${escapeHtml(r.name)}</strong></td>
          <td><a href="tel:+91${r.phone}" style="color:var(--admin-primary); text-decoration:none; font-weight:600;">+91 ${r.phone}</a></td>
          <td><span style="font-weight:600;">${escapeHtml(r.outletName)}</span></td>
          <td><span class="badge ${badgeClass}">${r.prizeTitle}</span></td>
          <td>${!isMiss ? `<span class="coupon-code-pill">${r.couponCode}</span>` : '<span style="color:#94a3b8;">—</span>'}</td>
          <td>
            ${isMiss ? '<span style="color:#94a3b8; font-size:0.75rem;">No Prize</span>' : 
              r.isRedeemed ? '<span class="badge badge-redeemed">✓ Redeemed</span>' : '<span class="badge badge-pending">⏳ Pending</span>'}
          </td>
          <td>
            ${(!isMiss && !r.isRedeemed) ? `
              <button class="btn-sm-action btn-redeem" onclick="markRecordRedeemed('${r.couponCode}')">Mark Redeemed</button>
            ` : '—'}
          </td>
        </tr>
      `;
    }).join('');
  }

  // --- Tab Management ---

  function setupTabs() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
      item.addEventListener('click', () => {
        const targetTab = item.getAttribute('data-tab');
        if (!targetTab) return;

        navItems.forEach(i => i.classList.remove('active'));
        item.classList.add('active');

        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        const pane = document.getElementById(`tab-${targetTab}`);
        if (pane) pane.classList.add('active');

        // Update top title
        const titleEl = document.getElementById('tabHeaderTitle');
        const titles = {
          overview: 'Dashboard Overview',
          outlets: '70 Cafe Outlets & QR Codes',
          records: 'Customer Entries & Spin History',
          quotas: '100-Spin Quota & Odds Monitor',
          cashier: 'Cashier Quick Redeem Terminal',
          settings: 'Store Rules & Settings'
        };
        if (titleEl && titles[targetTab]) {
          titleEl.textContent = titles[targetTab];
        }

        activeTab = targetTab;
      });
    });
  }

  // --- Render Metrics Cards ---

  function renderMetrics() {
    const totalSpins = allRecords.length;
    const redeemedCount = allRecords.filter(r => r.isRedeemed).length;
    const chaiCount = allRecords.filter(r => r.prizeKey === 'chai').length;
    const burgerCount = allRecords.filter(r => r.prizeKey === 'burger').length;
    const pizzaCount = allRecords.filter(r => r.prizeKey === 'pizza').length;
    const discCount = allRecords.filter(r => r.prizeKey === 'off15' || r.prizeKey === 'off25').length;

    setText('metricTotalSpins', totalSpins);
    setText('metricTotalOutlets', allOutlets.length);
    setText('sidebarOutletCount', `${allOutlets.length} Outlets Configured`);
    setText('metricTotalChai', chaiCount);
    setText('metricTotalBurgers', burgerCount);
    setText('metricTotalPizzas', pizzaCount);
    setText('metricTotalDiscounts', discCount);
    setText('metricTotalRedeemed', `${redeemedCount} / ${totalSpins}`);
  }

  function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }

  // --- Render Outlets Grid ---

  function renderOutletsGrid() {
    const container = document.getElementById('outletsGridContainer');
    if (!container) return;

    if (allOutlets.length === 0) {
      container.innerHTML = `
        <div class="outlet-empty-state">
          <span class="empty-icon">🏪</span>
          <h4>No Outlets Added Yet</h4>
          <p>You haven't added any cafe stores yet. Click the button below to add your first outlet. Each store automatically receives a dedicated customer spin URL, printable QR Code standee, and an isolated 100-spin quota engine.</p>
          <button class="btn-admin btn-admin-primary" onclick="openAddOutletModal()" style="font-weight:700; padding:10px 22px;">
            <span>➕</span> Add Your First Outlet
          </button>
        </div>
      `;
      return;
    }

    const searchInput = document.getElementById('outletSearchInput');
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const baseUrl = getBaseUrl();

    const filtered = allOutlets.filter(o => 
      (o.name && o.name.toLowerCase().includes(query)) ||
      (o.city && o.city.toLowerCase().includes(query)) ||
      (o.code && o.code.toLowerCase().includes(query)) ||
      (o.location && o.location.toLowerCase().includes(query))
    );

    if (filtered.length === 0) {
      container.innerHTML = `<div style="grid-column: 1/-1; text-align:center; padding: 40px; color:#64748b;">No outlets match your search.</div>`;
      return;
    }

    container.innerHTML = filtered.map(o => {
      const spins = o.currentSpinsInCycle || 0;
      const pct = Math.min(100, Math.round((spins / 100) * 100));
      const wins = o.cycleWins || { chai: 0, burger: 0, pizza: 0, off15: 0, off25: 0 };
      const outletUrl = `${baseUrl}/index.html?outlet=${o.id}`;

      return `
        <div class="outlet-admin-card">
          <div class="outlet-card-top">
            <div>
              <div class="outlet-card-name">${escapeHtml(o.name)}</div>
              <div class="outlet-card-loc">📍 ${escapeHtml(o.location || '')}, ${escapeHtml(o.city || '')}</div>
            </div>
            <span class="outlet-card-code">${escapeHtml(o.code || '')}</span>
          </div>

          <div class="outlet-card-progress">
            <div class="progress-header">
              <span>Cycle #${o.cycleNumber || 1} Progress</span>
              <span><strong>${spins}</strong> / 100 Spins</span>
            </div>
            <div class="progress-bar-bg">
              <div class="progress-bar-fill" style="width: ${pct}%"></div>
            </div>
            <div class="outlet-card-quotas">
              <span class="quota-tag" title="7 per 100 spins">☕ Chai: ${wins.chai || 0}/7</span>
              <span class="quota-tag" title="3 per 100 spins">🍔 Burger: ${wins.burger || 0}/3</span>
              <span class="quota-tag" title="3 per 100 spins">🍕 Pizza: ${wins.pizza || 0}/3</span>
              <span class="quota-tag" title="5 per 100 spins">🏷️ 15%: ${wins.off15 || 0}/5</span>
              <span class="quota-tag" title="1 per 100 spins">🌟 25%: ${wins.off25 || 0}/1</span>
            </div>
          </div>

          <div class="outlet-card-actions" style="flex-wrap:wrap;">
            <button class="btn-admin" onclick="copyOutletLink('${outletUrl}', '${escapeHtml(o.name)}')" title="Copy Customer Link">
              📋 Copy Link
            </button>
            <a href="standee.html?outlet=${o.id}" target="_blank" class="btn-admin btn-admin-gold" title="Generate Table Standee & QR Code">
              🖨️ QR Standee
            </a>
            <a href="${outletUrl}" target="_blank" class="btn-admin btn-admin-primary" title="Test Customer Game">
              🎯 Test
            </a>
            <button class="btn-admin" onclick="openEditOutletModal('${o.id}')" title="Edit Store Details">
              ✏️ Edit
            </button>
            <button class="btn-admin btn-admin-danger" onclick="deleteOutletConfirm('${o.id}', '${escapeHtml(o.name)}')" title="Delete Store">
              🗑️ Delete
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  // --- Render Customer Records Table ---

  function renderRecordsTable() {
    const tbody = document.getElementById('recordsTableBody');
    if (!tbody) return;

    const searchInput = document.getElementById('searchRecordsInput');
    const storeFilter = document.getElementById('filterStoreSelect');
    const prizeFilter = document.getElementById('filterPrizeSelect');
    const statusFilter = document.getElementById('filterStatusSelect');

    const search = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const selStore = storeFilter ? storeFilter.value : '';
    const selPrize = prizeFilter ? prizeFilter.value : '';
    const selStatus = statusFilter ? statusFilter.value : '';

    let list = allRecords;

    if (selStore) {
      list = list.filter(r => r.outletId === selStore);
    }
    if (selPrize) {
      list = list.filter(r => r.prizeKey === selPrize);
    }
    if (selStatus === 'redeemed') {
      list = list.filter(r => r.isRedeemed);
    } else if (selStatus === 'pending') {
      list = list.filter(r => !r.isRedeemed && r.prizeKey !== 'miss');
    }

    if (search) {
      list = list.filter(r => 
        (r.name && r.name.toLowerCase().includes(search)) ||
        (r.phone && r.phone.includes(search)) ||
        (r.couponCode && r.couponCode.toLowerCase().includes(search)) ||
        (r.outletName && r.outletName.toLowerCase().includes(search))
      );
    }

    const countEl = document.getElementById('recordsCountDisplay');
    if (countEl) countEl.textContent = `${list.length} records`;

    if (list.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding: 40px; color: #94a3b8;">No customer entries found matching the filter.</td></tr>`;
      return;
    }

    tbody.innerHTML = list.map(r => {
      const badgeClass = {
        chai: 'badge-chai',
        burger: 'badge-burger',
        pizza: 'badge-pizza',
        off15: 'badge-15off',
        off25: 'badge-25off',
        miss: 'badge-miss'
      }[r.prizeKey] || 'badge-miss';

      const isMiss = r.prizeKey === 'miss';

      return `
        <tr>
          <td><span style="font-size:0.75rem; color:#64748b;">${r.timeDisplay || r.dateStr || ''}</span></td>
          <td><strong>${escapeHtml(r.name)}</strong></td>
          <td><a href="tel:+91${r.phone}" style="color:var(--admin-primary); text-decoration:none; font-weight:600;">+91 ${r.phone}</a></td>
          <td><span style="font-weight:600;">${escapeHtml(r.outletName)}</span> <span style="font-size:0.7rem; color:#64748b;">(${r.outletCode})</span></td>
          <td><span class="badge ${badgeClass}">${r.prizeTitle}</span></td>
          <td>
            ${!isMiss ? `<span class="coupon-code-pill">${r.couponCode}</span>` : '<span style="color:#94a3b8;">—</span>'}
          </td>
          <td>
            ${isMiss ? '<span style="color:#94a3b8; font-size:0.75rem;">No Prize</span>' : 
              r.isRedeemed ? 
                `<span class="badge badge-redeemed" title="Redeemed on ${r.redeemedTimeDisplay || r.redeemedAt}">✓ Redeemed</span>` : 
                `<span class="badge badge-pending">⏳ Pending</span>`
            }
          </td>
          <td>
            ${(!isMiss && !r.isRedeemed) ? `
              <button class="btn-sm-action btn-redeem" onclick="markRecordRedeemed('${r.couponCode}')">
                Mark Redeemed
              </button>
            ` : (!isMiss && r.isRedeemed) ? `
              <span style="font-size:0.72rem; color:#15803d; font-weight:600;">Redeemed</span>
            ` : '—'}
          </td>
        </tr>
      `;
    }).join('');
  }

  // --- Render Quota Monitor ---

  function renderQuotaMonitor() {
    const tbody = document.getElementById('quotaMonitorTableBody');
    if (!tbody) return;

    if (allOutlets.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:36px; color:#94a3b8;">No outlets configured yet. Click <strong>"➕ Add New Outlet"</strong> in the Outlets tab to add your first store.</td></tr>`;
      return;
    }

    tbody.innerHTML = allOutlets.map(o => {
      const spins = o.currentSpinsInCycle || 0;
      const wins = o.cycleWins || { chai: 0, burger: 0, pizza: 0, off15: 0, off25: 0 };
      const remSpins = Math.max(0, 100 - spins);
      const remChai = Math.max(0, 7 - (wins.chai || 0));
      const remBurger = Math.max(0, 3 - (wins.burger || 0));
      const remPizza = Math.max(0, 3 - (wins.pizza || 0));
      const rem15 = Math.max(0, 5 - (wins.off15 || 0));
      const rem25 = Math.max(0, 1 - (wins.off25 || 0));

      return `
        <tr>
          <td><strong>${escapeHtml(o.name)}</strong> <span style="color:#64748b; font-size:0.75rem;">(${escapeHtml(o.code || '')})</span></td>
          <td><span style="font-weight:700; color:var(--admin-primary);">Cycle #${o.cycleNumber || 1}</span></td>
          <td>
            <strong>${spins}</strong> / 100 <span style="font-size:0.72rem; color:#64748b;">(${remSpins} left)</span>
          </td>
          <td><span style="color:#065f46; font-weight:700;">${wins.chai || 0}</span> / 7 <span style="font-size:0.7rem; color:#94a3b8;">(${remChai} left)</span></td>
          <td><span style="color:#b45309; font-weight:700;">${wins.burger || 0}</span> / 3 <span style="font-size:0.7rem; color:#94a3b8;">(${remBurger} left)</span></td>
          <td><span style="color:#b91c1c; font-weight:700;">${wins.pizza || 0}</span> / 3 <span style="font-size:0.7rem; color:#94a3b8;">(${remPizza} left)</span></td>
          <td><span style="color:#1d4ed8; font-weight:700;">${wins.off15 || 0}</span> / 5 <span style="font-size:0.7rem; color:#94a3b8;">(${rem15} left)</span></td>
          <td><span style="color:#6d28d9; font-weight:700;">${wins.off25 || 0}</span> / 1 <span style="font-size:0.7rem; color:#94a3b8;">(${rem25} left)</span></td>
          <td>
            <button class="btn-sm-action btn-copy" onclick="triggerResetCycle('${o.id}', '${escapeHtml(o.name)}')" title="Reset this outlet's 100-spin cycle">
              🔄 Reset Cycle
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  // --- Populate Store Filter Dropdown ---

  function populateStoreFilterDropdown() {
    const sel = document.getElementById('filterStoreSelect');
    if (!sel) return;

    const currentVal = sel.value;
    sel.innerHTML = '<option value="">All Outlets (All Stores)</option>';

    allOutlets.forEach(o => {
      const opt = document.createElement('option');
      opt.value = o.id;
      opt.textContent = `${o.code || ''} - ${o.name} (${o.city || ''})`.trim();
      sel.appendChild(opt);
    });

    if (currentVal && allOutlets.some(o => o.id === currentVal)) {
      sel.value = currentVal;
    }
  }

  // --- Filter and Search Listeners ---

  function setupFilters() {
    ['searchRecordsInput', 'filterStoreSelect', 'filterPrizeSelect', 'filterStatusSelect'].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('input', renderRecordsTable);
        el.addEventListener('change', renderRecordsTable);
      }
    });

    const outletSearch = document.getElementById('outletSearchInput');
    if (outletSearch) {
      outletSearch.addEventListener('input', renderOutletsGrid);
    }
  }

  // --- Cashier Quick Terminal ---

  function setupCashierTerminal() {
    const cashierInput = document.getElementById('cashierCodeInput');
    const cashierBtn = document.getElementById('btnCashierVerify');

    if (cashierBtn) {
      cashierBtn.addEventListener('click', async () => {
        const val = cashierInput.value.trim();
        if (!val) {
          showAdminToast('Please enter a voucher code or customer phone number', 'warning');
          return;
        }

        cashierBtn.disabled = true;
        cashierBtn.textContent = 'Verifying...';

        const res = await DataStore.redeemCoupon(val);

        cashierBtn.disabled = false;
        cashierBtn.textContent = 'Verify & Redeem Voucher';

        const resultBox = document.getElementById('cashierResultBox');
        if (res.error) {
          resultBox.innerHTML = `
            <div style="background:#fef2f2; border:1px solid #fecaca; border-radius:8px; padding:16px; color:#b91c1c;">
              <strong>❌ Voucher Not Found:</strong> ${res.error}
            </div>
          `;
          return;
        }

        if (res.alreadyRedeemed) {
          resultBox.innerHTML = `
            <div style="background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:16px; color:#b45309;">
              <strong>⚠️ Already Redeemed:</strong> ${res.message}
              <div style="margin-top:8px; font-size:0.85rem;">
                Customer: <strong>${res.record.name}</strong> (${res.record.phone}) | Prize: <strong>${res.record.prizeTitle}</strong>
              </div>
            </div>
          `;
          return;
        }

        if (res.success) {
          resultBox.innerHTML = `
            <div style="background:#ecfdf5; border:1px solid #a7f3d0; border-radius:8px; padding:20px; color:#065f46;">
              <h3 style="font-size:1.2rem; margin-bottom:6px;">✅ SUCCESS: VOUCHER REDEEMED!</h3>
              <p style="font-size:0.95rem;">Customer: <strong>${res.record.name}</strong> (+91 ${res.record.phone})</p>
              <p style="font-size:0.95rem;">Prize: <strong>${res.record.prizeTitle}</strong></p>
              <p style="font-size:0.85rem; color:#047857; margin-top:8px;">
                Verified under order rules: Min ₹110 bill. Redeemed at ${res.record.redeemedTimeDisplay}.
              </p>
            </div>
          `;
          cashierInput.value = '';
          await loadData(false);
        }
      });
    }
  }

  // --- Helper Functions ---

  function getBaseUrl() {
    if (serverStatus && serverStatus.localIP) {
      return `http://${serverStatus.localIP}:${serverStatus.port || 8080}`;
    }
    return window.location.origin;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // --- Global Handlers Exposed to Window ---

  window.copyOutletLink = (url, name) => {
    navigator.clipboard.writeText(url).then(() => {
      showAdminToast(`Link copied for ${name}! 📋`, 'success');
    }).catch(() => {
      prompt('Copy Link:', url);
    });
  };

  window.markRecordRedeemed = async (couponCode) => {
    if (!confirm(`Confirm redemption for coupon code ${couponCode}?`)) return;
    const res = await DataStore.redeemCoupon(couponCode);
    if (res.success) {
      showAdminToast('Voucher redeemed successfully! ✅', 'success');
      await loadData(false);
    } else {
      showAdminToast(res.message || res.error, 'warning');
    }
  };

  window.triggerResetCycle = async (outletId, outletName) => {
    if (!confirm(`Are you sure you want to reset the 100-spin cycle for "${outletName}"? This will restart spin count at 1 and restore full prize quotas.`)) return;
    const res = await DataStore.resetCycle(outletId);
    if (res.success) {
      showAdminToast(`Cycle reset for ${outletName}! 🔄`, 'success');
      await loadData(false);
    }
  };

  window.exportRecordsToCSV = () => {
    if (allRecords.length === 0) {
      showAdminToast('No records to export.', 'warning');
      return;
    }

    const headers = ['Record ID', 'Timestamp', 'Customer Name', 'Mobile Number', 'Outlet Code', 'Outlet Name', 'Outlet City', 'Prize Won', 'Coupon Code', 'Redeemed Status', 'Redeemed At'];

    const rows = allRecords.map(r => [
      `"${r.id || ''}"`,
      `"${r.timeDisplay || r.timestamp || ''}"`,
      `"${(r.name || '').replace(/"/g, '""')}"`,
      `"${r.phone || ''}"`,
      `"${r.outletCode || ''}"`,
      `"${(r.outletName || '').replace(/"/g, '""')}"`,
      `"${(r.outletCity || '').replace(/"/g, '""')}"`,
      `"${r.prizeTitle || ''}"`,
      `"${r.couponCode || ''}"`,
      `"${r.isRedeemed ? 'Redeemed' : 'Pending'}"`,
      `"${r.redeemedTimeDisplay || r.redeemedAt || ''}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Global_Tea_Cafe_Spins_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showAdminToast('Exported customer records to CSV! 📊', 'success');
  };

  function showAdminToast(msg, type = 'info') {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: ${type === 'success' ? '#15803d' : type === 'warning' ? '#b45309' : '#0f172a'};
      color: #fff;
      padding: 12px 20px;
      border-radius: 8px;
      font-size: 0.88rem;
      font-weight: 600;
      box-shadow: 0 10px 25px rgba(0,0,0,0.2);
      z-index: 9999;
      transition: all 0.25s;
    `;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 250);
    }, 3200);
  }

  // Settings Form (Change ID & Password)
  function setupSettingsForm() {
    const credsForm = document.getElementById('changePasswordForm');
    if (!credsForm) return;

    credsForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const newUser = document.getElementById('newAdminUser').value.trim();
      const newPass = document.getElementById('newAdminPass').value.trim();
      const btnSave = document.getElementById('btnSaveAdminCreds');

      if (newUser.length < 3 || newPass.length < 4) {
        showAdminToast('ID must be at least 3 chars and password at least 4 chars', 'warning');
        return;
      }

      if (btnSave) {
        btnSave.disabled = true;
        btnSave.textContent = 'Saving...';
      }

      const res = await DataStore.adminChangePassword(newUser, newPass);

      if (btnSave) {
        btnSave.disabled = false;
        btnSave.textContent = 'Save New Credentials';
      }

      if (res && res.success) {
        showAdminToast('Admin credentials updated successfully! 🔑', 'success');
        document.getElementById('newAdminPass').value = '';
      } else {
        showAdminToast((res && res.error) || 'Failed to update credentials', 'warning');
      }
    });
  }

  // Setup Add / Edit Outlet Modal Form
  function setupOutletModalForm() {
    const form = document.getElementById('outletModalForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('modalOutletId').value.trim();
      const name = document.getElementById('modalOutletName').value.trim();
      const code = document.getElementById('modalOutletCode').value.trim();
      const city = document.getElementById('modalOutletCity').value.trim();
      const location = document.getElementById('modalOutletLocation').value.trim();
      const btnSave = document.getElementById('btnSaveOutletModal');

      if (!name) {
        showAdminToast('Please provide an outlet name', 'warning');
        return;
      }

      if (btnSave) {
        btnSave.disabled = true;
        btnSave.textContent = 'Saving Store...';
      }

      let res;
      if (id) {
        res = await DataStore.updateOutlet({ id, name, code, city, location });
      } else {
        res = await DataStore.createOutlet({ name, code, city, location });
      }

      if (btnSave) {
        btnSave.disabled = false;
        btnSave.textContent = '💾 Save Outlet';
      }

      if (res && (res.success || res.outlet)) {
        showAdminToast(res.message || 'Outlet saved successfully! 🏪', 'success');
        closeOutletModal();
        await loadData(false);
      } else {
        showAdminToast((res && (res.error || res.message)) || 'Failed to save outlet.', 'warning');
      }
    });
  }

  // Window Handlers: Add / Edit / Delete Outlet
  window.openAddOutletModal = () => {
    const overlay = document.getElementById('outletModalOverlay');
    const title = document.getElementById('outletModalTitle');
    const form = document.getElementById('outletModalForm');
    if (!overlay) return;

    if (form) form.reset();
    document.getElementById('modalOutletId').value = '';
    if (title) title.textContent = '➕ Add New Cafe Outlet';

    const codeInput = document.getElementById('modalOutletCode');
    if (codeInput) {
      const nextNum = String(allOutlets.length + 1).padStart(2, '0');
      codeInput.value = `GTC-${nextNum}`;
    }

    overlay.style.display = 'flex';
    setTimeout(() => {
      const nameInput = document.getElementById('modalOutletName');
      if (nameInput) nameInput.focus();
    }, 50);
  };

  window.openEditOutletModal = (outletId) => {
    const outlet = allOutlets.find(o => o.id === outletId);
    if (!outlet) return;

    const overlay = document.getElementById('outletModalOverlay');
    const title = document.getElementById('outletModalTitle');
    if (!overlay) return;

    document.getElementById('modalOutletId').value = outlet.id;
    document.getElementById('modalOutletName').value = outlet.name || '';
    document.getElementById('modalOutletCode').value = outlet.code || '';
    document.getElementById('modalOutletCity').value = outlet.city || '';
    document.getElementById('modalOutletLocation').value = outlet.location || '';

    if (title) title.textContent = `✏️ Edit Outlet: ${outlet.name}`;
    overlay.style.display = 'flex';
  };

  window.closeOutletModal = () => {
    const overlay = document.getElementById('outletModalOverlay');
    if (overlay) overlay.style.display = 'none';
  };

  window.deleteOutletConfirm = async (outletId, outletName) => {
    if (!confirm(`Are you sure you want to delete outlet "${outletName}"?\n\nThis will remove its customer spin link, printable QR standee, and quota tracking.`)) {
      return;
    }
    const res = await DataStore.deleteOutlet(outletId);
    if (res && res.success) {
      showAdminToast(`Outlet "${outletName}" deleted.`, 'info');
      await loadData(false);
    } else {
      showAdminToast((res && res.error) || 'Failed to delete outlet.', 'warning');
    }
  };

  // Toggle Password Field Eye Icon
  window.togglePasswordVisibility = () => {
    const input = document.getElementById('adminPassword');
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
  };

  // Logout Admin Handler
  window.handleAdminLogout = () => {
    if (!confirm('Are you sure you want to logout from the Admin Portal?')) return;
    DataStore.adminLogout();
    if (pollInterval) {
      clearInterval(pollInterval);
      pollInterval = null;
    }
    const overlay = document.getElementById('adminLoginOverlay');
    if (overlay) overlay.style.display = 'flex';
    const passInput = document.getElementById('adminPassword');
    if (passInput) passInput.value = '';
    showAdminToast('Logged out successfully.', 'info');
  };
});
