@echo off
title Global Tea Cafe - Spin & Admin Server
color 0A
cls
echo ============================================================
echo      GLOBAL TEA CAFE - 70 OUTLETS SPIN GAME & ADMIN
echo ============================================================
echo Starting local server on port 8080...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
